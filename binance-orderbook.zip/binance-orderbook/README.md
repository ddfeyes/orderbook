# Binance OrderBook Visualization

Real-time Binance orderbook visualization with Canvas rendering, exactly like the Binance trading interface.

## Features

- **Real-time Data**: Connects to Binance REST API for initial snapshot and WebSocket for live updates
- **Canvas Rendering**: High-performance Canvas-based visualization with smooth animations
- **Binance-like UI**: Exact color scheme, layout, and animations matching Binance interface
- **Auto-reconnection**: Robust connection handling with automatic reconnection
- **Sequence Validation**: Proper sequence ID validation to prevent data gaps
- **Optimized Performance**: Batched updates, compression, and efficient rendering

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Binance API   │    │   Local Server   │    │   Web Client    │
│                 │    │                  │    │                 │
│ REST (snapshot) │───▶│ OrderBook Store  │───▶│ Canvas Renderer │
│ WebSocket (diff)│───▶│ WebSocket Server │───▶│ Real-time UI    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Installation

1. **Clone and install dependencies:**
```bash
cd binance-orderbook
npm install
```

2. **Start development server:**
```bash
npm run dev
```

This will start:
- Backend server on port 8080 (WebSocket) and 3001 (HTTP)
- Frontend development server on port 3000

3. **Open browser:**
```
http://localhost:3000
```

## Production Build

```bash
npm run build
npm start
```

## API Endpoints

### REST API

- `GET /health` - Service health check
- `GET /api/orderbook/:symbol` - Get orderbook snapshot
- `GET /api/symbol/:symbol/info` - Get symbol information

### WebSocket API

Connect to `ws://localhost:8080` and send:

```json
{
  "type": "subscribe",
  "data": {
    "symbol": "BTCUSDT",
    "stream": "depth"
  }
}
```

## Configuration

### Server Configuration

Edit `server/index.js` to modify:
- Symbol (default: BTCUSDT)
- Update frequency
- Maximum orderbook levels
- Reconnection settings

### Client Configuration

Edit `client/main.ts` to modify:
- Canvas dimensions
- Animation settings
- Color scheme
- Update batching

## File Structure

```
binance-orderbook/
├── client/                 # Frontend (Canvas + TypeScript)
│   ├── index.html         # Main HTML file
│   ├── main.ts           # Client application entry
│   ├── orderbook-renderer.ts  # Canvas rendering engine
│   └── vite.config.js    # Vite configuration
├── server/                # Backend (Node.js)
│   ├── index.js          # Main server file
│   ├── binance-rest.js   # Binance REST API client
│   ├── binance-websocket.js  # Binance WebSocket client
│   ├── local-orderbook.js    # Local orderbook management
│   └── websocket-server.js   # WebSocket server for clients
├── shared/               # Shared types and utilities
│   └── types.ts         # TypeScript type definitions
└── package.json         # Dependencies and scripts
```

## Key Components

### 1. Binance REST Client (`server/binance-rest.js`)
- Fetches initial orderbook snapshot
- Handles rate limiting and errors
- Validates symbols and gets exchange info

### 2. Binance WebSocket Client (`server/binance-websocket.js`)
- Subscribes to real-time depth updates
- Handles reconnection with exponential backoff
- Validates message sequence

### 3. Local OrderBook (`server/local-orderbook.js`)
- Maintains local orderbook state
- Applies differential updates
- Validates sequence IDs
- Emits change events

### 4. WebSocket Server (`server/websocket-server.js`)
- Serves real-time data to web clients
- Batches updates for performance
- Handles client subscriptions
- Compression and heartbeat

### 5. Canvas Renderer (`client/orderbook-renderer.ts`)
- High-performance Canvas rendering
- Smooth animations and transitions
- Binance-style color scheme
- Responsive design

## Performance Optimizations

1. **Batched Updates**: Groups multiple updates into single messages
2. **Compression**: WebSocket compression for reduced bandwidth
3. **Canvas Optimization**: Efficient rendering with animation frames
4. **Memory Management**: Limits orderbook depth and cleans old data
5. **Connection Pooling**: Reuses connections and handles reconnection

## Monitoring

The service provides health check endpoint with detailed status:

```bash
curl http://localhost:3001/health
```

Returns:
- Service status
- OrderBook statistics
- WebSocket connection info
- Binance connection status

## Troubleshooting

### Common Issues

1. **Connection Errors**: Check internet connection and Binance API status
2. **Sequence Gaps**: Service automatically reinitializes on gaps
3. **Performance Issues**: Reduce `maxLevels` or increase `batchTimeout`
4. **Memory Usage**: Monitor with `/health` endpoint

### Logs

The service provides detailed logging:
- `[REST]` - Binance REST API calls
- `[WS]` - Binance WebSocket events
- `[OrderBook]` - Local orderbook operations
- `[WS Server]` - Client WebSocket server
- `[Service]` - Main service events

## License

MIT License - see LICENSE file for details.

## Contributing

1. Fork the repository
2. Create feature branch
3. Add tests for new features
4. Submit pull request

## Disclaimer

This is for educational purposes only. Not affiliated with Binance. Use at your own risk.
