/**
 * Binance-style Candlestick Chart Implementation
 * Реализация свечного графика в стиле Binance
 */

class CandlestickChart {
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        this.canvas = null;
        this.ctx = null;
        this.data = [];
        this.currentTimeframe = '1m';
        this.symbol = 'BTCUSDT';
        
        // Chart dimensions
        this.width = 0;
        this.height = 0;
        this.padding = { top: 20, right: 80, bottom: 60, left: 20 };
        
        // Price range
        this.minPrice = 0;
        this.maxPrice = 0;
        this.priceRange = 0;
        
        // Time range
        this.startTime = 0;
        this.endTime = 0;
        this.timeRange = 0;

        // Interactive features
        this.scrollOffset = 0;
        this.zoomLevel = 1;
        this.minZoom = 0.1;
        this.maxZoom = 10;
        this.candleWidth = 8;
        this.candleSpacing = 2;
        this.visibleCandles = 100;

        // Mouse interaction
        this.mouseX = 0;
        this.mouseY = 0;
        this.isMouseOver = false;
        this.isDragging = false;
        this.lastMouseX = 0;
        this.dragStartX = 0;

        // Crosshair
        this.showCrosshair = false;
        this.crosshairPrice = 0;
        this.crosshairTime = 0;
        this.crosshairX = 0;
        this.crosshairY = 0;

        // Colors (Binance style)
        this.colors = {
            background: '#1e2329',
            grid: '#2b3139',
            text: '#848e9c',
            textBright: '#eaecef',
            green: '#0ecb81',
            red: '#f6465d',
            yellow: '#f0b90b',
            crosshair: '#848e9c'
        };
        
        // Timeframes
        this.timeframes = [
            { label: '1s', value: '1s', ms: 1000 },
            { label: '1m', value: '1m', ms: 60000 },
            { label: '3m', value: '3m', ms: 180000 },
            { label: '5m', value: '5m', ms: 300000 },
            { label: '15m', value: '15m', ms: 900000 },
            { label: '30m', value: '30m', ms: 1800000 },
            { label: '1h', value: '1h', ms: 3600000 },
            { label: '2h', value: '2h', ms: 7200000 },
            { label: '4h', value: '4h', ms: 14400000 },
            { label: '6h', value: '6h', ms: 21600000 },
            { label: '8h', value: '8h', ms: 28800000 },
            { label: '12h', value: '12h', ms: 43200000 },
            { label: '1d', value: '1d', ms: 86400000 },
            { label: '3d', value: '3d', ms: 259200000 },
            { label: '1w', value: '1w', ms: 604800000 },
            { label: '1M', value: '1M', ms: 2592000000 }
        ];
        
        this.init();
    }
    
    init() {
        this.createUI();
        this.createCanvas();
        this.setupEventListeners();
        this.loadInitialData();
    }
    
    createUI() {
        // Create timeframe selector
        const timeframeContainer = document.createElement('div');
        timeframeContainer.className = 'timeframe-selector';
        timeframeContainer.innerHTML = `
            <div class="timeframe-buttons">
                ${this.timeframes.map(tf => 
                    `<button class="timeframe-btn ${tf.value === this.currentTimeframe ? 'active' : ''}" 
                             data-timeframe="${tf.value}">${tf.label}</button>`
                ).join('')}
            </div>
        `;
        
        // Create chart header
        const headerContainer = document.createElement('div');
        headerContainer.className = 'chart-header';
        headerContainer.innerHTML = `
            <div class="chart-title">
                <span class="chart-symbol">${this.symbol}</span>
                <span class="chart-timeframe">${this.currentTimeframe}</span>
            </div>
            <div class="chart-price-info">
                <span class="current-price">--</span>
                <span class="price-change">--</span>
                <span class="price-change-percent">--</span>
            </div>
        `;
        
        // Create chart container
        const chartContainer = document.createElement('div');
        chartContainer.className = 'chart-container';
        
        // Append to main container
        this.container.innerHTML = '';
        this.container.appendChild(headerContainer);
        this.container.appendChild(timeframeContainer);
        this.container.appendChild(chartContainer);
        
        this.chartContainer = chartContainer;
    }
    
    createCanvas() {
        this.canvas = document.createElement('canvas');
        this.canvas.className = 'candlestick-canvas';
        this.ctx = this.canvas.getContext('2d');
        
        this.chartContainer.appendChild(this.canvas);
        this.resizeCanvas();
    }
    
    resizeCanvas() {
        const rect = this.chartContainer.getBoundingClientRect();
        this.width = rect.width;
        this.height = rect.height;
        
        // Set canvas size with device pixel ratio for crisp rendering
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;
        this.canvas.style.width = this.width + 'px';
        this.canvas.style.height = this.height + 'px';
        
        this.ctx.scale(dpr, dpr);
        this.draw();
    }
    
    setupEventListeners() {
        // Timeframe buttons
        this.container.addEventListener('click', (e) => {
            if (e.target.classList.contains('timeframe-btn')) {
                const timeframe = e.target.dataset.timeframe;
                this.changeTimeframe(timeframe);
            }
        });

        // Resize handler
        window.addEventListener('resize', () => {
            this.resizeCanvas();
        });



        this.canvas.addEventListener('mouseenter', (e) => {
            this.isMouseOver = true;
            this.showCrosshair = true;
        });

        this.canvas.addEventListener('mouseleave', (e) => {
            this.isMouseOver = false;
            this.showCrosshair = false;
            this.draw();
        });

        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            this.mouseX = e.clientX - rect.left;
            this.mouseY = e.clientY - rect.top;

            if (this.isMouseOver) {
                this.updateCrosshair();
                // Throttle mousemove drawing
                if (!this.mouseMoveThrottle) {
                    this.mouseMoveThrottle = true;
                    requestAnimationFrame(() => {
                        this.mouseMoveThrottle = false;
                        this.draw();
                    });
                }
            }

            if (this.isDragging) {
                this.handleDrag(e);
            }
        });

        // Mouse wheel for zoom and scroll
        this.canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            this.handleWheel(e);
        });

        // Mouse drag for panning
        this.canvas.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.dragStartX = e.clientX;
            this.lastMouseX = e.clientX;
            this.canvas.style.cursor = 'grabbing';
        });

        this.canvas.addEventListener('mouseup', (e) => {
            this.isDragging = false;
            this.canvas.style.cursor = 'crosshair';
        });

        // Touch events for mobile
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            if (e.touches.length === 1) {
                const touch = e.touches[0];
                this.isDragging = true;
                this.dragStartX = touch.clientX;
                this.lastMouseX = touch.clientX;
            }
        });

        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            if (e.touches.length === 1 && this.isDragging) {
                const touch = e.touches[0];
                this.handleDrag({ clientX: touch.clientX });
            }
        });

        this.canvas.addEventListener('touchend', (e) => {
            e.preventDefault();
            this.isDragging = false;
        });

        // Set initial cursor
        this.canvas.style.cursor = 'crosshair';
    }
    
    async loadInitialData() {
        try {
            await this.fetchKlineData();
            this.calculatePriceRange();
            this.draw();
        } catch (error) {
            console.error('Failed to load initial data:', error);
        }
    }
    
    roundTimeToInterval(timestamp, interval) {
        const date = new Date(timestamp);

        switch(interval) {
            case '1s':
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours(), date.getMinutes(), date.getSeconds()).getTime();
            case '1m':
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours(), date.getMinutes()).getTime();
            case '3m':
                const minutes3 = Math.floor(date.getMinutes() / 3) * 3;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours(), minutes3).getTime();
            case '5m':
                const minutes5 = Math.floor(date.getMinutes() / 5) * 5;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours(), minutes5).getTime();
            case '15m':
                const minutes15 = Math.floor(date.getMinutes() / 15) * 15;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours(), minutes15).getTime();
            case '30m':
                const minutes30 = Math.floor(date.getMinutes() / 30) * 30;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours(), minutes30).getTime();
            case '1h':
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                               date.getHours()).getTime();
            case '2h':
                const hours2 = Math.floor(date.getHours() / 2) * 2;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours2).getTime();
            case '4h':
                const hours4 = Math.floor(date.getHours() / 4) * 4;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours4).getTime();
            case '6h':
                const hours6 = Math.floor(date.getHours() / 6) * 6;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours6).getTime();
            case '8h':
                const hours8 = Math.floor(date.getHours() / 8) * 8;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours8).getTime();
            case '12h':
                const hours12 = Math.floor(date.getHours() / 12) * 12;
                return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours12).getTime();
            case '1d':
                return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
            case '3d':
                const dayOfYear = Math.floor((date - new Date(date.getFullYear(), 0, 0)) / 86400000);
                const day3 = Math.floor(dayOfYear / 3) * 3;
                return new Date(date.getFullYear(), 0, day3).getTime();
            case '1w':
                const dayOfWeek = date.getDay();
                const monday = new Date(date);
                monday.setDate(date.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1));
                return new Date(monday.getFullYear(), monday.getMonth(), monday.getDate()).getTime();
            case '1M':
                return new Date(date.getFullYear(), date.getMonth()).getTime();
            default:
                return timestamp;
        }
    }

    async fetchKlineData() {
        // Increased data load for better chart experience
        const limit = 1000; // Increased from 200 to 1000 candles for better performance
        const url = `https://api.binance.com/api/v3/klines?symbol=${this.symbol}&interval=${this.currentTimeframe}&limit=${limit}`;

        try {
            const response = await fetch(url);
            const data = await response.json();

            this.data = data.map(kline => {
                const openTime = parseInt(kline[0]);
                const roundedTime = this.roundTimeToInterval(openTime, this.currentTimeframe);

                return {
                    openTime: roundedTime,
                    open: parseFloat(kline[1]),
                    high: parseFloat(kline[2]),
                    low: parseFloat(kline[3]),
                    close: parseFloat(kline[4]),
                    volume: parseFloat(kline[5]),
                    closeTime: parseInt(kline[6])
                };
            });

            this.updatePriceInfo();
        } catch (error) {
            console.error('Error fetching kline data:', error);
            throw error;
        }
    }
    
    calculatePriceRange() {
        if (this.data.length === 0) return;

        // Calculate visible data range based on scroll and zoom
        const visibleData = this.getVisibleData();
        if (visibleData.length === 0) return;

        this.minPrice = Math.min(...visibleData.map(d => d.low));
        this.maxPrice = Math.max(...visibleData.map(d => d.high));
        this.priceRange = this.maxPrice - this.minPrice;

        // Add 5% padding
        const padding = this.priceRange * 0.05;
        this.minPrice -= padding;
        this.maxPrice += padding;
        this.priceRange = this.maxPrice - this.minPrice;

        // Time range for visible data
        if (visibleData.length > 0) {
            this.startTime = visibleData[0].openTime;
            this.endTime = visibleData[visibleData.length - 1].closeTime;
            this.timeRange = this.endTime - this.startTime;
        }
    }

    getVisibleData() {
        if (this.data.length === 0) return [];

        // Calculate how many candles can fit in the visible area
        const chartWidth = this.width - this.padding.left - this.padding.right;
        const candleFullWidth = (this.candleWidth + this.candleSpacing) * this.zoomLevel;
        this.visibleCandles = Math.floor(chartWidth / candleFullWidth);

        // Calculate start index based on scroll offset
        const maxOffset = Math.max(0, this.data.length - this.visibleCandles);
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxOffset));

        const startIndex = Math.floor(this.scrollOffset);
        const endIndex = Math.min(startIndex + this.visibleCandles, this.data.length);

        return this.data.slice(startIndex, endIndex);
    }
    
    draw() {
        if (!this.ctx || this.data.length === 0) return;

        // Throttle drawing to improve performance - use 60fps target
        if (this.drawThrottle) return;
        this.drawThrottle = true;

        requestAnimationFrame(() => {
            this.drawThrottle = false;
            this.doDraw();
        });
    }

    doDraw() {
        // Clear canvas
        this.ctx.fillStyle = this.colors.background;
        this.ctx.fillRect(0, 0, this.width, this.height);

        // Recalculate price range for visible data
        this.calculatePriceRange();

        this.drawGrid();
        this.drawPriceScale();
        this.drawTimeScale();
        this.drawCandlesticks();

        // Draw crosshair if mouse is over
        if (this.showCrosshair) {
            this.drawCrosshair();
        }
    }
    
    drawGrid() {
        this.ctx.strokeStyle = this.colors.grid;
        this.ctx.lineWidth = 1;
        
        const chartWidth = this.width - this.padding.left - this.padding.right;
        const chartHeight = this.height - this.padding.top - this.padding.bottom;
        
        // Horizontal grid lines (price levels)
        const priceSteps = 8;
        for (let i = 0; i <= priceSteps; i++) {
            const y = this.padding.top + (chartHeight * i / priceSteps);
            this.ctx.beginPath();
            this.ctx.moveTo(this.padding.left, y);
            this.ctx.lineTo(this.width - this.padding.right, y);
            this.ctx.stroke();
        }
        
        // Vertical grid lines (time)
        const timeSteps = 6;
        for (let i = 0; i <= timeSteps; i++) {
            const x = this.padding.left + (chartWidth * i / timeSteps);
            this.ctx.beginPath();
            this.ctx.moveTo(x, this.padding.top);
            this.ctx.lineTo(x, this.height - this.padding.bottom);
            this.ctx.stroke();
        }
    }
    
    drawPriceScale() {
        this.ctx.fillStyle = this.colors.text;
        this.ctx.font = '11px SF Mono, Monaco, monospace';
        this.ctx.textAlign = 'left';
        
        const chartHeight = this.height - this.padding.top - this.padding.bottom;
        const priceSteps = 8;
        
        for (let i = 0; i <= priceSteps; i++) {
            const y = this.padding.top + (chartHeight * i / priceSteps);
            const price = this.maxPrice - (this.priceRange * i / priceSteps);
            
            this.ctx.fillText(
                price.toFixed(2),
                this.width - this.padding.right + 5,
                y + 4
            );
        }
    }
    
    drawTimeScale() {
        this.ctx.fillStyle = this.colors.text;
        this.ctx.font = '11px SF Mono, Monaco, monospace';
        this.ctx.textAlign = 'center';
        
        const chartWidth = this.width - this.padding.left - this.padding.right;
        const timeSteps = 6;
        
        for (let i = 0; i <= timeSteps; i++) {
            const x = this.padding.left + (chartWidth * i / timeSteps);
            const time = this.startTime + (this.timeRange * i / timeSteps);
            const roundedTime = this.roundTimeToInterval(time, this.currentTimeframe);
            const date = new Date(roundedTime);

            let timeStr;
            if (this.currentTimeframe.includes('d') || this.currentTimeframe.includes('w') || this.currentTimeframe.includes('M')) {
                timeStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            } else {
                timeStr = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
            }

            this.ctx.fillText(timeStr, x, this.height - this.padding.bottom + 15);
        }
    }
    
    drawCandlesticks() {
        const chartWidth = this.width - this.padding.left - this.padding.right;
        const chartHeight = this.height - this.padding.top - this.padding.bottom;

        // Get visible data
        const visibleData = this.getVisibleData();
        if (visibleData.length === 0) return;

        const candleFullWidth = (this.candleWidth + this.candleSpacing) * this.zoomLevel;
        const candleWidth = Math.max(1, this.candleWidth * this.zoomLevel);

        visibleData.forEach((candle, index) => {
            const x = this.padding.left + (index * candleFullWidth) + (candleFullWidth / 2);

            // Calculate y positions
            const highY = this.padding.top + ((this.maxPrice - candle.high) / this.priceRange) * chartHeight;
            const lowY = this.padding.top + ((this.maxPrice - candle.low) / this.priceRange) * chartHeight;
            const openY = this.padding.top + ((this.maxPrice - candle.open) / this.priceRange) * chartHeight;
            const closeY = this.padding.top + ((this.maxPrice - candle.close) / this.priceRange) * chartHeight;

            const isGreen = candle.close >= candle.open;
            const color = isGreen ? this.colors.green : this.colors.red;

            // Draw wick (high-low line)
            this.ctx.strokeStyle = color;
            this.ctx.lineWidth = 1;
            this.ctx.beginPath();
            this.ctx.moveTo(x, highY);
            this.ctx.lineTo(x, lowY);
            this.ctx.stroke();

            // Draw body (open-close rectangle)
            const bodyTop = Math.min(openY, closeY);
            const bodyHeight = Math.abs(closeY - openY);

            this.ctx.fillStyle = color;
            this.ctx.fillRect(x - candleWidth/2, bodyTop, candleWidth, Math.max(1, bodyHeight));
        });

        // Draw crosshair if mouse is over
        if (this.showCrosshair && this.isMouseOver) {
            this.drawCrosshair();
        }
    }
    
    updatePriceInfo() {
        if (this.data.length === 0) return;
        
        const currentCandle = this.data[this.data.length - 1];
        const previousCandle = this.data[this.data.length - 2];
        
        if (!currentCandle || !previousCandle) return;
        
        const currentPrice = currentCandle.close;
        const priceChange = currentPrice - previousCandle.close;
        const priceChangePercent = (priceChange / previousCandle.close) * 100;
        
        const currentPriceEl = this.container.querySelector('.current-price');
        const priceChangeEl = this.container.querySelector('.price-change');
        const priceChangePercentEl = this.container.querySelector('.price-change-percent');
        
        if (currentPriceEl) {
            currentPriceEl.textContent = currentPrice.toFixed(2);
            currentPriceEl.style.color = priceChange >= 0 ? this.colors.green : this.colors.red;
        }
        
        if (priceChangeEl) {
            priceChangeEl.textContent = (priceChange >= 0 ? '+' : '') + priceChange.toFixed(2);
            priceChangeEl.style.color = priceChange >= 0 ? this.colors.green : this.colors.red;
        }
        
        if (priceChangePercentEl) {
            priceChangePercentEl.textContent = `(${priceChange >= 0 ? '+' : ''}${priceChangePercent.toFixed(2)}%)`;
            priceChangePercentEl.style.color = priceChange >= 0 ? this.colors.green : this.colors.red;
        }
    }
    
    async changeTimeframe(timeframe) {
        if (timeframe === this.currentTimeframe) return;
        
        // Update active button
        this.container.querySelectorAll('.timeframe-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.timeframe === timeframe) {
                btn.classList.add('active');
            }
        });
        
        this.currentTimeframe = timeframe;
        
        // Update timeframe display
        const timeframeEl = this.container.querySelector('.chart-timeframe');
        if (timeframeEl) {
            timeframeEl.textContent = timeframe;
        }
        
        // Fetch new data
        try {
            await this.fetchKlineData();
            this.calculatePriceRange();
            this.draw();
        } catch (error) {
            console.error('Failed to change timeframe:', error);
        }
    }
    
    handleMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        this.mouseX = e.clientX - rect.left;
        this.mouseY = e.clientY - rect.top;

        // Calculate crosshair price and time
        this.updateCrosshairValues();

        if (this.showCrosshair) {
            this.draw();
        }
    }

    handleWheel(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;

        // Horizontal scroll (deltaX) - pan left/right
        if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
            const scrollSpeed = 3;
            const scrollDelta = e.deltaX > 0 ? scrollSpeed : -scrollSpeed;
            this.scrollOffset += scrollDelta;
            this.calculatePriceRange();
            this.draw();
        }
        // Vertical scroll (deltaY) - zoom in/out
        else {
            const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
            const newZoom = this.zoomLevel * zoomFactor;

            if (newZoom >= this.minZoom && newZoom <= this.maxZoom) {
                this.zoomLevel = newZoom;
                this.calculatePriceRange();
                this.draw();
            }
        }
    }

    handleDrag(e) {
        const deltaX = e.clientX - this.lastMouseX;
        const chartWidth = this.width - this.padding.left - this.padding.right;
        const candleFullWidth = (this.candleWidth + this.candleSpacing) * this.zoomLevel;
        const scrollDelta = -deltaX / candleFullWidth;

        this.scrollOffset += scrollDelta;
        this.lastMouseX = e.clientX;

        this.calculatePriceRange();
        this.draw();
    }



    updateCrosshair() {
        const chartWidth = this.width - this.padding.left - this.padding.right;
        const chartHeight = this.height - this.padding.top - this.padding.bottom;

        // Calculate price at mouse Y position
        const relativeY = (this.mouseY - this.padding.top) / chartHeight;
        this.crosshairPrice = this.maxPrice - (relativeY * this.priceRange);

        // Calculate time at mouse X position
        const relativeX = (this.mouseX - this.padding.left) / chartWidth;
        this.crosshairTime = this.startTime + (relativeX * this.timeRange);

        this.crosshairX = this.mouseX;
        this.crosshairY = this.mouseY;
    }

    drawCrosshair() {
        if (!this.showCrosshair) return;

        this.ctx.strokeStyle = this.colors.crosshair;
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([]);

        // Solid vertical line
        this.ctx.beginPath();
        this.ctx.moveTo(this.crosshairX, this.padding.top);
        this.ctx.lineTo(this.crosshairX, this.height - this.padding.bottom);
        this.ctx.stroke();

        // Solid horizontal line
        this.ctx.beginPath();
        this.ctx.moveTo(this.padding.left, this.crosshairY);
        this.ctx.lineTo(this.width - this.padding.right, this.crosshairY);
        this.ctx.stroke();

        // Price label
        this.drawCrosshairLabel(
            this.width - this.padding.right + 2,
            this.crosshairY,
            this.crosshairPrice.toFixed(2),
            'right'
        );

        // Time label
        const date = new Date(this.crosshairTime);
        let timeStr = this.formatTimeForCrosshair(date);

        this.drawCrosshairLabel(
            this.crosshairX,
            this.height - this.padding.bottom + 2,
            timeStr,
            'bottom'
        );
    }

    formatTimeForCrosshair(date) {
        if (this.currentTimeframe.includes('d') || this.currentTimeframe.includes('w') || this.currentTimeframe.includes('M')) {
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        } else {
            return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
        }
    }

    drawCrosshairLabel(x, y, text, position) {
        this.ctx.font = '11px SF Mono, Monaco, monospace';
        const metrics = this.ctx.measureText(text);
        const padding = 4;

        let labelX, labelY, labelWidth, labelHeight;

        if (position === 'right') {
            labelWidth = metrics.width + padding * 2;
            labelHeight = 16;
            labelX = x;
            labelY = y - labelHeight / 2;
        } else if (position === 'bottom') {
            labelWidth = metrics.width + padding * 2;
            labelHeight = 16;
            labelX = x - labelWidth / 2;
            labelY = y;
        }

        // Draw background
        this.ctx.fillStyle = this.colors.background;
        this.ctx.strokeStyle = this.colors.crosshair;
        this.ctx.lineWidth = 1;
        this.ctx.fillRect(labelX, labelY, labelWidth, labelHeight);
        this.ctx.strokeRect(labelX, labelY, labelWidth, labelHeight);

        // Draw text
        this.ctx.fillStyle = this.colors.textBright;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(text, labelX + labelWidth / 2, labelY + labelHeight / 2);
    }

    setSymbol(symbol) {
        this.symbol = symbol;
        const symbolEl = this.container.querySelector('.chart-symbol');
        if (symbolEl) {
            symbolEl.textContent = symbol;
        }
        this.loadInitialData();
    }
}

// Export for use in main.js
window.CandlestickChart = CandlestickChart;
