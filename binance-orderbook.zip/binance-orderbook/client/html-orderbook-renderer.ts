// HTML Orderbook Renderer - создает ордербук как на Binance
interface OrderBookLevel {
  price: string;
  quantity: string;
}

interface SymbolInfo {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  tickSize: string;
  stepSize: string;
  minNotional: string;
}

interface GroupingLevel {
  value: number;
  label: string;
}

interface OrderBookMetrics {
  totalBidsVolume: number;
  totalAsksVolume: number;
  totalBidsValue: number;
  totalAsksValue: number;
  averageExecutionPrice: number;
  volumeAtPlusPercent: number;
  volumeAtMinusPercent: number;
  currentPrice: number;
  liquidityPercent: number;
}

interface PriceImpactData {
  priceImpact: number;
  averagePrice: number;
  totalCost: number;
  totalVolume: number;
  side: 'bid' | 'ask';
}

interface OrderBookData {
  symbol: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread?: number;
  spreadPercent?: number;
  metrics: OrderBookMetrics;
  groupingLevel: GroupingLevel;
  symbolInfo?: SymbolInfo;
}

// Utility functions
function formatNumber(value: number | string, maxDecimals: number = 8): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  const formatted = num.toFixed(maxDecimals);
  return formatted.replace(/\.?0+$/, '');
}

function formatLargeNumber(value: number): string {
  if (value >= 1e9) {
    return formatNumber(value / 1e9, 2) + 'B';
  } else if (value >= 1e6) {
    return formatNumber(value / 1e6, 2) + 'M';
  } else if (value >= 1e3) {
    return formatNumber(value / 1e3, 2) + 'K';
  }
  return formatNumber(value, 2);
}

export class HTMLOrderBookRenderer {
  private data: OrderBookData | null = null;
  private previousData: OrderBookData | null = null;
  private asksContainer: HTMLElement;
  private bidsContainer: HTMLElement;
  private spreadElement: HTMLElement;
  private metricsElements: { [key: string]: HTMLElement } = {};
  private groupingElement: HTMLElement;
  private tooltip: HTMLElement;
  private isFirstRender: boolean = true;

  constructor() {
    // Получаем элементы DOM
    this.asksContainer = document.getElementById('asks-list')!;
    this.bidsContainer = document.getElementById('bids-list')!;
    this.spreadElement = document.getElementById('spread-info')!;
    this.groupingElement = document.getElementById('current-grouping')!;
    this.tooltip = document.getElementById('price-impact-tooltip')!;

    // Получаем элементы метрик
    this.metricsElements = {
      sumBtc: document.getElementById('sum-btc')!,
      sumUsdt: document.getElementById('sum-usdt')!,
      bidsVolume: document.getElementById('bids-volume')!,
      asksVolume: document.getElementById('asks-volume')!,
      plusVolume: document.getElementById('plus-volume')!,
      minusVolume: document.getElementById('minus-volume')!,
      currentPrice: document.getElementById('current-price')!,
      liquidityPercentPlus: document.getElementById('liquidity-percent-plus')!,
      liquidityPercentMinus: document.getElementById('liquidity-percent-minus')!
    };

    console.log('[HTMLRenderer] Initialized');
  }

  updateData(data: OrderBookData) {
    this.previousData = this.data;
    this.data = data;
    this.render();
  }

  private render() {
    if (!this.data) return;

    console.log('[HTMLRenderer] Rendering orderbook with', this.data.bids.length, 'bids and', this.data.asks.length, 'asks');

    console.log('[RENDER DEBUG] About to call renderAsks()');
    this.renderAsks();
    console.log('[RENDER DEBUG] About to call renderBids()');
    this.renderBids();
    this.renderSpread();
    this.renderMetrics();
    this.updateGrouping();
  }

  private getOrderChanges(currentOrders: OrderBookLevel[], previousOrders: OrderBookLevel[] | undefined, type: 'bid' | 'ask'): Map<string, 'new' | 'updated' | 'same'> {
    const changes = new Map<string, 'new' | 'updated' | 'same'>();

    if (!previousOrders) {
      // Если нет предыдущих данных, все ордера новые
      currentOrders.forEach(order => {
        changes.set(order.price, 'new');
      });
      return changes;
    }

    const previousMap = new Map(previousOrders.map(order => [order.price, order.quantity]));

    currentOrders.forEach(order => {
      const previousQuantity = previousMap.get(order.price);
      if (previousQuantity === undefined) {
        changes.set(order.price, 'new');
      } else if (previousQuantity !== order.quantity) {
        changes.set(order.price, 'updated');
      } else {
        changes.set(order.price, 'same');
      }
    });

    return changes;
  }

  private renderAsks() {
    console.log('[RENDER ASKS DEBUG] Starting renderAsks method');
    if (!this.data) return;

    try {

    // Получаем изменения ордеров
    const changes = this.getOrderChanges(
      this.data.asks,
      this.previousData?.asks,
      'ask'
    );

    // Сохраняем текущую позицию прокрутки
    const currentScrollTop = this.asksContainer.scrollTop;
    const isAtBottom = currentScrollTop >= (this.asksContainer.scrollHeight - this.asksContainer.clientHeight - 10);

    this.asksContainer.innerHTML = '';

    // Сначала реверсим для отображения (от дорогих к дешевым, как на Binance)
    const asksReversed = this.data.asks.slice().reverse();

    // Рассчитываем кумулятивные суммы в правильном порядке (от дешевых к дорогим)
    // Сначала создаем массив с кумулятивными суммами в исходном порядке (дешевые -> дорогие)
    let cumulativeTotal = 0;
    const asksWithCumulative = this.data.asks.map(ask => {
      const price = parseFloat(ask.price);
      const quantity = parseFloat(ask.quantity);
      cumulativeTotal += price * quantity;
      return { ...ask, cumulativeTotal };
    });

    // Теперь реверсим для отображения, сохраняя правильные кумулятивные суммы
    const asksToShow = asksWithCumulative.slice().reverse();

    // Debug: log first and last 3 asks to verify sorting
    console.log('[ASKS SORT DEBUG] Original first 3 asks:', JSON.stringify(this.data.asks.slice(0, 3).map(a => ({ price: a.price, quantity: a.quantity }))));
    console.log('[ASKS SORT DEBUG] Original last 3 asks:', JSON.stringify(this.data.asks.slice(-3).map(a => ({ price: a.price, quantity: a.quantity }))));
    console.log('[ASKS SORT DEBUG] To show first 3 asks:', JSON.stringify(asksToShow.slice(0, 3).map(a => ({ price: a.price, quantity: a.quantity }))));
    console.log('[ASKS SORT DEBUG] To show last 3 asks:', JSON.stringify(asksToShow.slice(-3).map(a => ({ price: a.price, quantity: a.quantity }))));

    asksToShow.forEach((ask, index) => {
      const changeType = changes.get(ask.price);
      const isNew = changeType === 'new';
      const isUpdated = changeType === 'updated';

      const levelElement = this.createLevelElement(ask, 'ask', index, ask.cumulativeTotal, isNew);

      // Добавляем анимации для изменений ордеров
      if (isNew) {
        levelElement.classList.add('new-order');
        setTimeout(() => {
          levelElement.classList.remove('new-order');
        }, 300);
      } else if (isUpdated) {
        levelElement.classList.add('flash-red');
        setTimeout(() => {
          levelElement.classList.remove('flash-red');
        }, 600);
      }

      this.asksContainer.appendChild(levelElement);
    });

    // Упрощенная логика прокрутки
    setTimeout(() => {
      if (this.isFirstRender) {
        // Первый рендер - прокручиваем к низу (ближе к спреду)
        this.asksContainer.scrollTop = this.asksContainer.scrollHeight - this.asksContainer.clientHeight;
        this.isFirstRender = false;
      } else if (isAtBottom) {
        // Пользователь был внизу - остаемся внизу
        this.asksContainer.scrollTop = this.asksContainer.scrollHeight - this.asksContainer.clientHeight;
      } else {
        // Сохраняем текущую позицию прокрутки без сложных вычислений
        this.asksContainer.scrollTop = currentScrollTop;
      }
    }, 0);

    } catch (error) {
      console.error('[RENDER ASKS ERROR]', error);
    }
  }

  private renderBids() {
    if (!this.data) return;

    // Получаем изменения ордеров
    const changes = this.getOrderChanges(
      this.data.bids,
      this.previousData?.bids,
      'bid'
    );

    this.bidsContainer.innerHTML = '';

    // Показываем все bids
    const bidsToShow = this.data.bids;

    // Логируем первые и последние биды для отладки сортировки
    console.log('[BIDS SORT DEBUG] First 3 bids:', JSON.stringify(bidsToShow.slice(0, 3).map(b => ({ price: parseFloat(b.price), quantity: parseFloat(b.quantity) }))));
    console.log('[BIDS SORT DEBUG] Last 3 bids:', JSON.stringify(bidsToShow.slice(-3).map(b => ({ price: parseFloat(b.price), quantity: parseFloat(b.quantity) }))));

    // Рассчитываем кумулятивные суммы для bids (сверху вниз)
    let cumulativeTotal = 0;
    const bidsWithCumulative = bidsToShow.map(bid => {
      const price = parseFloat(bid.price);
      const quantity = parseFloat(bid.quantity);
      cumulativeTotal += price * quantity;
      return { ...bid, cumulativeTotal };
    });

    bidsWithCumulative.forEach((bid, index) => {
      const changeType = changes.get(bid.price);
      const isNew = changeType === 'new';
      const isUpdated = changeType === 'updated';

      const levelElement = this.createLevelElement(bid, 'bid', index, bid.cumulativeTotal, isNew);

      // Добавляем анимации для изменений ордеров
      if (isNew) {
        levelElement.classList.add('new-order');
        setTimeout(() => {
          levelElement.classList.remove('new-order');
        }, 300);
      } else if (isUpdated) {
        levelElement.classList.add('flash-green');
        setTimeout(() => {
          levelElement.classList.remove('flash-green');
        }, 600);
      }

      this.bidsContainer.appendChild(levelElement);
    });
  }

  private createLevelElement(level: OrderBookLevel, type: 'bid' | 'ask', index: number, cumulativeTotal?: number, isNew: boolean = false): HTMLElement {
    const element = document.createElement('div');
    element.className = `orderbook-level ${type}`;

    // Добавляем анимацию для новых ордеров
    if (isNew) {
      element.classList.add('new-order');
    }

    const price = parseFloat(level.price);
    const quantity = parseFloat(level.quantity);
    const total = cumulativeTotal || (price * quantity);

    // Создаем фоновую полосу для визуализации объема
    const maxQuantity = this.getMaxQuantity();
    const widthPercent = maxQuantity > 0 ? (quantity / maxQuantity) * 100 : 0;

    element.style.background = type === 'bid'
      ? `linear-gradient(90deg, transparent ${100 - widthPercent}%, rgba(14, 203, 129, 0.12) 100%)`
      : `linear-gradient(90deg, transparent ${100 - widthPercent}%, rgba(246, 70, 93, 0.12) 100%)`;

    element.innerHTML = `
      <div class="level-price">${formatNumber(price, 2)}</div>
      <div class="level-amount">${formatNumber(quantity, 5)}</div>
      <div class="level-total">${formatLargeNumber(total)}</div>
    `;

    // Сохраняем данные для отслеживания изменений
    element.setAttribute('data-price', price.toString());
    element.setAttribute('data-quantity', quantity.toString());

    // Добавляем hover эффект и tooltip
    element.addEventListener('mouseenter', (e) => {
      element.style.background = 'rgba(255, 255, 255, 0.05)';
      this.showPriceImpactTooltip(e, type, index);
    });

    element.addEventListener('mouseleave', () => {
      element.style.background = type === 'bid'
        ? `linear-gradient(90deg, transparent ${100 - widthPercent}%, rgba(14, 203, 129, 0.12) 100%)`
        : `linear-gradient(90deg, transparent ${100 - widthPercent}%, rgba(246, 70, 93, 0.12) 100%)`;
      this.hidePriceImpactTooltip();
    });

    element.addEventListener('mousemove', (e) => {
      this.updateTooltipPosition(e);
    });

    return element;
  }

  private getMaxQuantity(): number {
    if (!this.data) return 0;

    // Берем первые 50 уровней для расчета максимального объема (для производительности)
    const topBids = this.data.bids.slice(0, 50);
    const topAsks = this.data.asks.slice(0, 50);
    const allLevels = [...topBids, ...topAsks];
    return Math.max(...allLevels.map(level => parseFloat(level.quantity)));
  }

  private renderSpread() {
    if (!this.data || !this.data.bids.length || !this.data.asks.length) return;

    const bestBid = parseFloat(this.data.bids[0].price);
    const bestAsk = parseFloat(this.data.asks[0].price);
    const spread = bestAsk - bestBid;
    const spreadPercent = (spread / bestBid) * 100;

    this.spreadElement.textContent = `Spread: ${formatNumber(spread, 2)} (${formatNumber(spreadPercent, 3)}%)`;
  }

  private renderMetrics() {
    if (!this.data) return;

    const metrics = this.data.metrics;

    this.metricsElements.sumBtc.textContent = formatNumber(metrics.totalBidsVolume, 3);
    this.metricsElements.sumUsdt.textContent = formatLargeNumber(metrics.totalBidsValue);
    this.metricsElements.bidsVolume.textContent = formatLargeNumber(metrics.totalBidsValue);
    this.metricsElements.asksVolume.textContent = formatLargeNumber(metrics.totalAsksValue);
    this.metricsElements.plusVolume.textContent = formatLargeNumber(metrics.volumeAtPlusPercent);
    this.metricsElements.minusVolume.textContent = formatLargeNumber(metrics.volumeAtMinusPercent);
    this.metricsElements.currentPrice.textContent = formatNumber(metrics.currentPrice, 2);
    this.metricsElements.liquidityPercentPlus.textContent = metrics.liquidityPercent.toString();
    this.metricsElements.liquidityPercentMinus.textContent = metrics.liquidityPercent.toString();
  }

  private showPriceImpactTooltip(event: MouseEvent, side: 'bid' | 'ask', index: number) {
    if (!this.data) return;

    // Нормализуем уровни и индекс: считаем от лучшей цены к более дальним
    const isBid = side === 'bid';
    const levels = isBid ? this.data.bids : this.data.asks; // bids: desc (best first), asks: asc (best first)
    const targetIndex = isBid ? index : (levels.length - 1 - index); // для asks DOM идёт сверху (дорогие), а лучшая цена внизу

    const currentPrice = this.data.metrics.currentPrice;

    // Логируем для отладки
    console.log(`[TOOLTIP DEBUG] ${side} domIndex=${index}, targetIndex=${targetIndex}, targetPrice=${levels[targetIndex]?.price}, targetQuantity=${levels[targetIndex]?.quantity}`);
    console.log(`[TOOLTIP DEBUG] First 3 ${side}s:`, levels.slice(0, 3).map(l => ({ price: l.price, quantity: l.quantity })));

    const impact = this.calculatePriceImpact(levels, targetIndex, side, currentPrice);

    // Обновляем содержимое tooltip
    document.getElementById('tooltip-price-impact')!.textContent = `${impact.priceImpact.toFixed(2)}%`;
    document.getElementById('tooltip-avg-price')!.textContent = formatNumber(impact.averagePrice, 2);
    document.getElementById('tooltip-total-cost')!.textContent = `${formatLargeNumber(impact.totalCost)} USDT`;
    document.getElementById('tooltip-volume')!.textContent = `${formatNumber(impact.totalVolume, 5)} BTC`;

    // Устанавливаем цвет для price impact (положительный — хуже, отрицательный — лучше)
    const impactElement = document.getElementById('tooltip-price-impact')!;
    impactElement.className = 'tooltip-value';
    if (impact.priceImpact > 0) {
      impactElement.classList.add('negative');
    } else if (impact.priceImpact < 0) {
      impactElement.classList.add('positive');
    }

    this.updateTooltipPosition(event);
    this.tooltip.classList.add('visible');
  }

  private hidePriceImpactTooltip() {
    this.tooltip.classList.remove('visible');
  }

  private updateTooltipPosition(event: MouseEvent) {
    const rect = this.tooltip.getBoundingClientRect();
    const x = event.clientX + 10;
    const y = event.clientY - rect.height / 2;

    // Проверяем, чтобы tooltip не выходил за границы экрана
    const maxX = window.innerWidth - rect.width - 10;
    const maxY = window.innerHeight - rect.height - 10;

    this.tooltip.style.left = `${Math.min(x, maxX)}px`;
    this.tooltip.style.top = `${Math.max(10, Math.min(y, maxY))}px`;
  }

  private calculatePriceImpact(
    levels: OrderBookLevel[],
    targetIndex: number,
    side: 'bid' | 'ask',
    currentPrice: number
  ): PriceImpactData {
    if (targetIndex < 0 || targetIndex >= levels.length) {
      return { priceImpact: 0, averagePrice: 0, totalCost: 0, totalVolume: 0, side };
    }

    let totalCost = 0;
    let totalVolume = 0;

    // Берем уровни от 0 (ближе к спреду) до targetIndex — для bid и ask используем порядок DOM
    for (let i = 0; i <= targetIndex; i++) {
      const level = levels[i];
      const price = parseFloat(level.price);
      const quantity = parseFloat(level.quantity);

      totalCost += price * quantity;
      totalVolume += quantity;
    }

    if (totalVolume === 0) {
      return { priceImpact: 0, averagePrice: 0, totalCost: 0, totalVolume: 0, side };
    }

    const averagePrice = totalCost / totalVolume;

    // Референсная цена: берём текущую (currentPrice), которую уже считаем как mid в metrics
    // Для асков импакт должен быть положительным, если средняя выше референса; для бидов — если ниже
    const priceImpact = (averagePrice - currentPrice) / currentPrice * 100;

    return {
      priceImpact,
      averagePrice,
      totalCost,
      totalVolume,
      side
    };
  }

  private updateGrouping() {
    if (!this.data) return;

    this.groupingElement.textContent = this.data.groupingLevel.label;
  }

  // Пустой метод resize для совместимости
  resize(width: number, height: number) {
    // HTML renderer не нуждается в resize
  }
}
