// Binance OrderBook Client
class BinanceOrderBook {
    constructor() {
        this.ws = null;
        this.orderBook = { bids: [], asks: [] };
        this.isConnected = false;
        this.currentSymbol = 'BTCUSDT';
        this.grouping = 0.01;
        this.liquidityPercent = 2;
        this.isFirstDataLoad = true; // Flag for first data load
        this.chart = null; // Candlestick chart instance

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initChart();
        this.connect();
    }

    setupEventListeners() {
        // Liquidity slider
        const liquiditySlider = document.getElementById('liquidity-slider');
        const liquidityValue = document.getElementById('liquidity-value');
        
        liquiditySlider.addEventListener('input', (e) => {
            const values = [0.1, 0.5, 1, 2, 5, 10, 20, 50];
            const value = values[parseInt(e.target.value)];
            this.liquidityPercent = value;
            liquidityValue.textContent = value + '%';
            document.getElementById('liquidity-percent-plus').textContent = value;
            document.getElementById('liquidity-percent-minus').textContent = value;
        });

        // Exchange selector
        const exchangeSelector = document.getElementById('exchange-selector');
        exchangeSelector.addEventListener('change', (e) => {
            // For now, we only support Binance
            if (e.target.value !== 'binance') {
                alert('Only Binance is currently supported');
                e.target.value = 'binance';
            }
        });

        // Initialize ping monitor
        this.initPingMonitor();
    }

    initChart() {
        // Initialize candlestick chart
        if (window.CandlestickChart) {
            this.chart = new window.CandlestickChart('chart-area');
            this.chart.setSymbol(this.currentSymbol);
            // Store chart instance globally for debugging
            window.candlestickChart = this.chart;
            console.log('Chart initialized successfully');
        } else {
            console.error('CandlestickChart class not found');
        }
    }

    initPingMonitor() {
        this.pingTimes = [];
        this.lastPingTime = Date.now();
        this.pingInterval = setInterval(() => {
            this.measureWebSocketPing();
        }, 2000); // More frequent ping monitoring

        // Initial ping measurement
        setTimeout(() => this.measureWebSocketPing(), 1000);
    }

    measureWebSocketPing() {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
            // Use simple HTTP ping as fallback
            this.measureHttpPing();
            return;
        }

        this.lastPingTime = Date.now();

        // Send ping through WebSocket
        try {
            this.ws.send(JSON.stringify({
                type: 'ping',
                timestamp: this.lastPingTime
            }));
        } catch (error) {
            console.error('Failed to send ping:', error);
            this.measureHttpPing();
        }
    }

    measureHttpPing() {
        const startTime = Date.now();

        // Use fast endpoint
        fetch('https://api.binance.com/api/v3/ping', {
            method: 'GET',
            cache: 'no-cache'
        })
        .then(() => {
            const pingTime = Date.now() - startTime;
            this.updatePingDisplay(pingTime);
        })
        .catch(() => {
            this.updatePingDisplay(null);
        });
    }

    handlePongMessage(data) {
        if (data.type === 'pong' && data.timestamp) {
            const pingTime = Date.now() - data.timestamp;
            this.updatePingDisplay(pingTime);
        }
    }

    updatePingDisplay(pingTime) {
        const pingIndicator = document.getElementById('ping-indicator');
        const pingValue = pingIndicator.querySelector('.ping-value');

        if (pingTime === null) {
            pingValue.textContent = '-- ms';
            pingIndicator.className = 'ping-indicator';
            return;
        }

        pingValue.textContent = `${pingTime} ms`;

        // Update color based on ping time
        pingIndicator.classList.remove('good', 'medium', 'bad');
        if (pingTime < 100) {
            pingIndicator.classList.add('good');
        } else if (pingTime < 300) {
            pingIndicator.classList.add('medium');
        } else {
            pingIndicator.classList.add('bad');
        }
    }

    connect() {
        try {
            this.updateStatus('connecting', 'Connecting...');
            this.ws = new WebSocket('ws://localhost:8080');
            
            this.ws.onopen = () => {
                console.log('Connected to Binance WebSocket');
                this.isConnected = true;
                this.updateStatus('connected', 'Connected');
                
                // Subscribe to orderbook
                this.subscribe();
            };

            this.ws.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    console.log('Received message:', message.type, message);
                    this.handleMessage(message);
                } catch (error) {
                    console.error('Error parsing message:', error);
                }
            };

            this.ws.onclose = () => {
                console.log('WebSocket connection closed');
                this.isConnected = false;
                this.updateStatus('disconnected', 'Disconnected');
                
                // Reconnect after 1 second
                setTimeout(() => this.connect(), 1000);
            };

            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.updateStatus('error', 'Connection Error');
            };

        } catch (error) {
            console.error('Failed to connect:', error);
            this.updateStatus('error', 'Connection Failed');
        }
    }

    subscribe() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            const subscribeMessage = {
                type: 'subscribe',
                data: {
                    symbol: this.currentSymbol
                }
            };
            this.ws.send(JSON.stringify(subscribeMessage));
            console.log('Subscribed to', this.currentSymbol);
        }
    }

    handleMessage(message) {
        switch (message.type) {
            case 'pong':
                this.handlePongMessage(message);
                break;
            case 'orderbook':
            case 'orderbook_update':
            case 'depth_update':
                if (message.data) {
                    this.updateOrderBook(message.data);
                }
                break;
            case 'batch_update':
                // Handle batched updates
                if (message.data && Array.isArray(message.data)) {
                    // Use the latest update from the batch
                    const latestUpdate = message.data[message.data.length - 1];
                    if (latestUpdate && latestUpdate.data) {
                        this.updateOrderBook(latestUpdate.data);
                    }
                }
                break;
            case 'orderbook_delta':
                if (message.data) {
                    this.updateOrderBook(message.data);
                }
                break;
            case 'connected':
            case 'subscribed':
                console.log('Server message:', message.type);
                break;
            case 'error':
                console.error('Server error:', message.error);
                break;
            default:
                // Log first few unknown messages for debugging
                if (!this.unknownMessageCount) this.unknownMessageCount = 0;
                if (this.unknownMessageCount < 3) {
                    console.log('Unknown message type:', message.type, message);
                    this.unknownMessageCount++;
                }
        }
    }

    updateOrderBook(data) {
        console.log('Updating orderbook with data:', data);
        this.orderBook = data;
        this.renderOrderBook();
        this.updateMetrics();
        this.hideLoading();

        // Mark that we've received first data
        if (this.isFirstDataLoad) {
            this.isFirstDataLoad = false;
        }
    }

    renderOrderBook() {
        // Throttle rendering to max 30 FPS for performance
        if (this.renderThrottle) return;
        this.renderThrottle = true;
        requestAnimationFrame(() => {
            this.renderThrottle = false;
            this.doRenderOrderBook();
        });
    }

    doRenderOrderBook() {
        console.log('Rendering orderbook with', this.orderBook.bids?.length, 'bids and', this.orderBook.asks?.length, 'asks');

        const bidsContainer = document.getElementById('bids-list');
        const asksContainer = document.getElementById('asks-list');

        if (!bidsContainer || !asksContainer) {
            console.error('Could not find orderbook containers');
            return;
        }

        // Store previous data for animation comparison
        if (!this.previousOrderBook) {
            this.previousOrderBook = { bids: [], asks: [] };
        }

        // Check if this is the first render (initial load)
        const isFirstRender = this.isFirstDataLoad || (!this.previousOrderBook.asks.length && !this.previousOrderBook.bids.length);

        // Render bids (green, buy orders) - show ALL available orders
        const bids = this.orderBook.bids || [];
        this.renderOrderSide(bidsContainer, bids, 'bid', this.previousOrderBook.bids);

        // Render asks (red, sell orders) - show ALL available orders, reverse for display
        const asks = this.orderBook.asks || [];
        // Create a copy for display (reversed) but keep original order for calculations
        const asksForDisplay = [...asks].reverse();
        this.renderOrderSide(asksContainer, asksForDisplay, 'ask', this.previousOrderBook.asks);

        // Store current data for next comparison (keep original order)
        this.previousOrderBook = {
            bids: bids,
            asks: asks  // Keep original order, not reversed
        };

        // Auto-scroll asks to bottom on first render or page refresh
        if (isFirstRender) {
            this.scrollAsksToBottom();
        }

        // Update spread
        this.updateSpread();
    }

    scrollAsksToBottom() {
        const asksContainer = document.getElementById('asks-list');
        if (asksContainer) {
            // Use setTimeout to ensure DOM is updated
            setTimeout(() => {
                asksContainer.scrollTop = asksContainer.scrollHeight;
                console.log('Auto-scrolled asks to bottom');
            }, 100);
        }
    }

    renderOrderSide(container, orders, side, previousOrders) {
        // Create a map of previous orders for quick lookup
        const previousMap = new Map();
        previousOrders.forEach(order => {
            const price = parseFloat(order.price || order[0]);
            const amount = parseFloat(order.quantity || order[1]);
            previousMap.set(price.toString(), amount);
        });

        // Clear container
        container.innerHTML = '';

        orders.forEach((order, index) => {
            const element = this.createOrderElement(order, side, index, previousMap);
            container.appendChild(element);
        });
    }

    createOrderElement(order, side, index, previousMap) {
        const div = document.createElement('div');
        div.className = `orderbook-level ${side}`;
        div.style.cursor = 'pointer';

        const price = parseFloat(order.price || order[0]);
        const amount = parseFloat(order.quantity || order[1]);
        const total = price * amount;

        // Check if this order changed
        const priceKey = price.toString();
        const previousAmount = previousMap ? previousMap.get(priceKey) : undefined;
        let changeClass = '';

        if (previousAmount !== undefined) {
            if (amount > previousAmount) {
                changeClass = side === 'bid' ? 'order-increased-green' : 'order-increased-red';
            } else if (amount < previousAmount) {
                changeClass = side === 'bid' ? 'order-decreased-green' : 'order-decreased-red';
            }
        } else if (previousMap && previousMap.size > 0) {
            changeClass = side === 'bid' ? 'order-new-green' : 'order-new-red';
        }

        // Calculate percentage for background bar
        const maxAmount = Math.max(...(this.orderBook[side + 's'] || []).map(o => parseFloat(o.quantity || o[1])));
        const percentage = (amount / maxAmount) * 100;

        div.innerHTML = `
            <div class="level-price ${changeClass}">${this.formatPrice(price)}</div>
            <div class="level-amount ${changeClass}">${this.formatAmount(amount)}</div>
            <div class="level-total ${changeClass}">${this.formatTotal(total)}</div>
            <div class="level-bar ${side}" style="width: ${percentage}%"></div>
        `;

        // Add price impact calculation on hover
        div.addEventListener('mouseenter', (e) => {
            this.showPriceImpact(e, price, side);
        });

        div.addEventListener('mouseleave', () => {
            this.hidePriceImpact();
        });

        // Add animation class and remove it after animation
        if (changeClass) {
            div.classList.add(changeClass);
            setTimeout(() => {
                div.classList.remove(changeClass);
            }, 500);
        }

        return div;
    }

    updateSpread() {
        const bids = this.orderBook.bids || [];
        const asks = this.orderBook.asks || [];

        if (bids.length > 0 && asks.length > 0) {
            const bestBid = parseFloat(bids[0].price || bids[0][0]);
            const bestAsk = parseFloat(asks[0].price || asks[0][0]);
            const spread = bestAsk - bestBid;
            const spreadPercent = ((spread / bestBid) * 100).toFixed(4);

            document.getElementById('spread-info').textContent =
                `${this.formatPrice(spread)} (${spreadPercent}%)`;
        }
    }

    updateMetrics() {
        const bids = this.orderBook.bids || [];
        const asks = this.orderBook.asks || [];
        
        let totalBidsVolume = 0;
        let totalAsksVolume = 0;
        let totalBidsValue = 0;
        let totalAsksValue = 0;

        // Calculate totals
        bids.forEach(bid => {
            const price = parseFloat(bid.price || bid[0]);
            const amount = parseFloat(bid.quantity || bid[1]);
            totalBidsVolume += amount;
            totalBidsValue += price * amount;
        });

        asks.forEach(ask => {
            const price = parseFloat(ask.price || ask[0]);
            const amount = parseFloat(ask.quantity || ask[1]);
            totalAsksVolume += amount;
            totalAsksValue += price * amount;
        });

        // Update UI
        document.getElementById('sum-btc').textContent = this.formatAmount(totalBidsVolume + totalAsksVolume);
        document.getElementById('sum-usdt').textContent = this.formatTotal(totalBidsValue + totalAsksValue);
        document.getElementById('bids-volume').textContent = this.formatTotal(totalBidsValue);
        document.getElementById('asks-volume').textContent = this.formatTotal(totalAsksValue);
        
        // Current price (best bid)
        if (bids.length > 0) {
            const currentPrice = parseFloat(bids[0].price || bids[0][0]);
            document.getElementById('current-price').textContent = this.formatPrice(currentPrice);
        }

        // Liquidity calculations
        this.calculateLiquidityMetrics();
    }

    calculateLiquidityMetrics() {
        const bids = this.orderBook.bids || [];
        const asks = this.orderBook.asks || [];
        
        if (bids.length === 0 || asks.length === 0) return;

        const currentPrice = parseFloat(bids[0].price || bids[0][0]);
        const plusPrice = currentPrice * (1 + this.liquidityPercent / 100);
        const minusPrice = currentPrice * (1 - this.liquidityPercent / 100);

        let plusVolume = 0;
        let minusVolume = 0;

        // Calculate volume within liquidity range
        asks.forEach(ask => {
            const price = parseFloat(ask.price || ask[0]);
            const amount = parseFloat(ask.quantity || ask[1]);
            if (price <= plusPrice) {
                plusVolume += amount;
            }
        });

        bids.forEach(bid => {
            const price = parseFloat(bid.price || bid[0]);
            const amount = parseFloat(bid.quantity || bid[1]);
            if (price >= minusPrice) {
                minusVolume += amount;
            }
        });

        document.getElementById('plus-volume').textContent = this.formatAmount(plusVolume);
        document.getElementById('minus-volume').textContent = this.formatAmount(minusVolume);
    }

    updateStatus(status, text) {
        const statusDot = document.getElementById('status-dot');
        const statusText = document.getElementById('status-text');
        
        statusDot.className = 'status-dot';
        if (status === 'connected') {
            statusDot.classList.add('connected');
        }
        
        statusText.textContent = text;
    }

    hideLoading() {
        const loading = document.getElementById('loading');
        if (loading) {
            loading.style.display = 'none';
        }
    }

    formatPrice(price) {
        return parseFloat(price).toFixed(2);
    }

    formatAmount(amount) {
        return parseFloat(amount).toFixed(6);
    }

    formatTotal(total) {
        if (total >= 1000000) {
            return (total / 1000000).toFixed(2) + 'M';
        } else if (total >= 1000) {
            return (total / 1000).toFixed(2) + 'K';
        }
        return parseFloat(total).toFixed(2);
    }

    showPriceImpact(event, targetPrice, side) {
        const impact = this.calculatePriceImpact(targetPrice, side);

        // Create or update tooltip
        let tooltip = document.getElementById('price-impact-tooltip');
        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.id = 'price-impact-tooltip';
            tooltip.className = 'price-impact-tooltip';
            document.body.appendChild(tooltip);
        }

        // Apply color scheme based on side
        tooltip.className = `price-impact-tooltip ${side === 'ask' ? 'ask-tooltip' : 'bid-tooltip'}`;

        tooltip.innerHTML = `
            <div class="tooltip-row">
                <span class="tooltip-label">Target Price:</span>
                <span class="tooltip-value">${this.formatPrice(targetPrice)}</span>
            </div>
            <div class="tooltip-row">
                <span class="tooltip-label">Average Price:</span>
                <span class="tooltip-value">${this.formatPrice(impact.avgPrice)}</span>
            </div>
            <div class="tooltip-row">
                <span class="tooltip-label">Price Impact:</span>
                <span class="tooltip-value ${impact.impact > 0 ? 'negative' : 'positive'}">${impact.impact.toFixed(4)}%</span>
            </div>
            <div class="tooltip-row">
                <span class="tooltip-label">Total Volume:</span>
                <span class="tooltip-value">${this.formatAmount(impact.totalVolume)} BTC</span>
            </div>
            <div class="tooltip-row">
                <span class="tooltip-label">Total Cost:</span>
                <span class="tooltip-value">${this.formatTotal(impact.totalCost)} USDT</span>
            </div>
        `;

        // Position tooltip in Chart Area, aligned to the right edge
        const chartArea = document.querySelector('.chart-area');
        const orderRow = event.target.getBoundingClientRect();

        if (chartArea) {
            const chartRect = chartArea.getBoundingClientRect();

            // Position tooltip at the right edge of chart area
            // and aligned with the hovered order row vertically
            tooltip.style.left = (chartRect.right - 220 - 10) + 'px'; // 220px tooltip width + 10px margin
            tooltip.style.top = Math.max(10, orderRow.top - 10) + 'px';

            // Ensure tooltip doesn't go off screen
            const tooltipRect = tooltip.getBoundingClientRect();
            if (tooltipRect.bottom > window.innerHeight - 10) {
                tooltip.style.top = (window.innerHeight - tooltipRect.height - 10) + 'px';
            }
            if (tooltipRect.left < 10) {
                tooltip.style.left = '10px';
            }
        } else {
            // Fallback: position to the right of the hovered element
            const rect = event.target.getBoundingClientRect();
            tooltip.style.left = (rect.right + 10) + 'px';
            tooltip.style.top = rect.top + 'px';
        }

        tooltip.classList.add('visible');
    }

    hidePriceImpact() {
        const tooltip = document.getElementById('price-impact-tooltip');
        if (tooltip) {
            tooltip.classList.remove('visible');
        }
    }

    calculatePriceImpact(targetPrice, side) {
        const orders = side === 'bid' ? this.orderBook.bids : this.orderBook.asks;
        const currentPrice = side === 'bid' ?
            parseFloat(this.orderBook.bids[0]?.price || this.orderBook.bids[0]?.[0] || 0) :
            parseFloat(this.orderBook.asks[0]?.price || this.orderBook.asks[0]?.[0] || 0);

        let totalVolume = 0;
        let totalCost = 0;

        for (const order of orders) {
            const price = parseFloat(order.price || order[0]);
            const amount = parseFloat(order.quantity || order[1]);

            // For asks: accumulate from lowest price UP TO target price (inclusive)
            // For bids: accumulate from highest price DOWN TO target price (inclusive)
            if (side === 'ask' && price > targetPrice) break;
            if (side === 'bid' && price < targetPrice) break;

            totalVolume += amount;
            totalCost += price * amount;
        }

        const avgPrice = totalVolume > 0 ? totalCost / totalVolume : currentPrice;
        const impact = ((avgPrice - currentPrice) / currentPrice) * 100;

        return {
            avgPrice,
            impact,
            totalVolume,
            totalCost
        };
    }

    // Method to change symbol for both orderbook and chart
    changeSymbol(newSymbol) {
        if (newSymbol === this.currentSymbol) return;

        this.currentSymbol = newSymbol;

        // Update chart symbol
        if (this.chart) {
            this.chart.setSymbol(newSymbol);
        }

        // Update orderbook header
        const headerElement = document.querySelector('.orderbook-header h2');
        if (headerElement) {
            headerElement.textContent = `${newSymbol} Order Book`;
        }

        // Update current symbol display
        const symbolElement = document.getElementById('current-symbol');
        if (symbolElement) {
            symbolElement.textContent = newSymbol.replace('USDT', '/USDT');
        }

        // Resubscribe to new symbol
        if (this.isConnected) {
            this.subscribe();
        }
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.orderbook = new BinanceOrderBook();

    // Also scroll asks to bottom on page refresh/reload
    window.addEventListener('beforeunload', () => {
        window.orderbook.isFirstDataLoad = true;
    });
});
