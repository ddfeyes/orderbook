import { HTMLOrderBookRenderer } from './html-orderbook-renderer';

// Types
interface SymbolInfo {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  tickSize: string;
  stepSize: string;
  minNotional: string;
}

interface GroupingLevel {
  value: number;
  label: string;
}

interface OrderBookMetrics {
  totalBidsVolume: number;
  totalAsksVolume: number;
  totalBidsValue: number;
  totalAsksValue: number;
  averageExecutionPrice: number;
  volumeAtPlusPercent: number;
  volumeAtMinusPercent: number;
  currentPrice: number;
  liquidityPercent: number;
}

interface WebSocketMessage {
  type: string;
  data?: any;
  error?: string;
  timestamp?: number;
}

// Utility functions
function formatNumber(value: number | string, maxDecimals: number = 8): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  const formatted = num.toFixed(maxDecimals);
  return formatted.replace(/\.?0+$/, '');
}

function formatLargeNumber(value: number): string {
  if (value >= 1e9) {
    return formatNumber(value / 1e9, 2) + 'B';
  } else if (value >= 1e6) {
    return formatNumber(value / 1e6, 2) + 'M';
  } else if (value >= 1e3) {
    return formatNumber(value / 1e3, 2) + 'K';
  }
  return formatNumber(value, 2);
}

function generateGroupingLevels(tickSize: string): GroupingLevel[] {
  const tick = parseFloat(tickSize);
  return [
    { value: tick, label: formatNumber(tick) },
    { value: tick * 10, label: formatNumber(tick * 10) },
    { value: tick * 100, label: formatNumber(tick * 100) },
    { value: tick * 1000, label: formatNumber(tick * 1000) }
  ];
}

function groupOrderBookLevels(
  levels: any[],
  groupingLevel: GroupingLevel,
  isBids: boolean = true
): any[] {
  if (groupingLevel.value <= 0) return levels;

  const grouped = new Map<string, number>();

  for (const level of levels) {
    const price = parseFloat(level.price);
    const quantity = parseFloat(level.quantity);

    let groupedPrice: number;
    if (isBids) {
      groupedPrice = Math.floor(price / groupingLevel.value) * groupingLevel.value;
    } else {
      groupedPrice = Math.ceil(price / groupingLevel.value) * groupingLevel.value;
    }

    const priceKey = groupedPrice.toFixed(8);
    const existingQuantity = grouped.get(priceKey) || 0;
    grouped.set(priceKey, existingQuantity + quantity);
  }

  const result = Array.from(grouped.entries()).map(([price, quantity]) => ({
    price: formatNumber(parseFloat(price)),
    quantity: formatNumber(quantity)
  }));

  result.sort((a, b) => {
    const priceA = parseFloat(a.price);
    const priceB = parseFloat(b.price);
    return isBids ? priceB - priceA : priceA - priceB;
  });

  return result;
}

function calculateOrderBookMetrics(
  bids: any[],
  asks: any[],
  cursorPosition?: number,
  currentPrice?: number,
  liquidityPercent: number = 2
): OrderBookMetrics {
  const totalBidsVolume = bids.reduce((sum, level) => sum + parseFloat(level.quantity), 0);
  const totalAsksVolume = asks.reduce((sum, level) => sum + parseFloat(level.quantity), 0);

  const totalBidsValue = bids.reduce((sum, level) => {
    return sum + (parseFloat(level.price) * parseFloat(level.quantity));
  }, 0);

  const totalAsksValue = asks.reduce((sum, level) => {
    return sum + (parseFloat(level.price) * parseFloat(level.quantity));
  }, 0);

  let averageExecutionPrice = 0;
  if (cursorPosition !== undefined && bids.length > 0) {
    const levelsUpToCursor = bids.slice(0, cursorPosition + 1);
    let totalValue = 0;
    let totalVolume = 0;

    for (const level of levelsUpToCursor) {
      const price = parseFloat(level.price);
      const quantity = parseFloat(level.quantity);
      totalValue += price * quantity;
      totalVolume += quantity;
    }

    averageExecutionPrice = totalVolume > 0 ? totalValue / totalVolume : 0;
  }

  const bestBid = bids.length > 0 ? parseFloat(bids[0].price) : 0;
  const bestAsk = asks.length > 0 ? parseFloat(asks[0].price) : 0;
  const midPrice = (bestBid + bestAsk) / 2;
  const price = currentPrice || midPrice;

  const multiplier = 1 + (liquidityPercent / 100);
  const upperBound = price * multiplier;
  const lowerBound = price / multiplier;

  let volumeAtPlusPercent = 0;
  let volumeAtMinusPercent = 0;

  for (const level of asks) {
    const askPrice = parseFloat(level.price);
    if (askPrice <= upperBound) {
      volumeAtPlusPercent += askPrice * parseFloat(level.quantity);
    } else {
      break;
    }
  }

  for (const level of bids) {
    const bidPrice = parseFloat(level.price);
    if (bidPrice >= lowerBound) {
      volumeAtMinusPercent += bidPrice * parseFloat(level.quantity);
    } else {
      break;
    }
  }

  return {
    totalBidsVolume,
    totalAsksVolume,
    totalBidsValue,
    totalAsksValue,
    averageExecutionPrice,
    volumeAtPlusPercent,
    volumeAtMinusPercent,
    currentPrice: price,
    liquidityPercent
  };
}

class OrderBookClient {
  private ws: WebSocket | null = null;
  private renderer: HTMLOrderBookRenderer;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private reconnectDelay = 1000;
  private isConnecting = false;
  private symbol = 'BTCUSDT';
  private symbolInfo: SymbolInfo | null = null;
  private groupingLevels: GroupingLevel[] = [];
  private currentGroupingIndex = 0;

  // UI elements
  private statusDot: HTMLElement;
  private statusText: HTMLElement;
  private loadingElement: HTMLElement;
  private errorElement: HTMLElement;
  private groupingSelect: HTMLSelectElement;
  private liquiditySlider: HTMLInputElement;
  private liquidityValue: HTMLElement;
  private currentLiquidityPercent: number = 2;
  private lastOrderBookData: any = null;

  // Performance monitoring
  private pingInterval: number | null = null;
  private lastPingTime: number = 0;
  private pingHistory: number[] = [];
  private maxPingHistory = 10;

  constructor() {
    this.initializeUI();
    this.initializeRenderer();
    this.fetchSymbolInfo();
    this.connect();
  }

  private initializeUI() {
    this.statusDot = document.getElementById('status-dot')!;
    this.statusText = document.getElementById('status-text')!;
    this.loadingElement = document.getElementById('loading')!;
    this.errorElement = document.getElementById('error')!;
    this.groupingSelect = document.getElementById('grouping-select') as HTMLSelectElement;
    this.liquiditySlider = document.getElementById('liquidity-slider') as HTMLInputElement;
    this.liquidityValue = document.getElementById('liquidity-value')!;

    // Handle window resize
    window.addEventListener('resize', () => {
      this.handleResize();
    });

    // Handle grouping change
    this.groupingSelect.addEventListener('change', () => {
      this.currentGroupingIndex = parseInt(this.groupingSelect.value);
      this.updateGrouping();
    });

    // Handle liquidity slider change
    this.liquiditySlider.addEventListener('input', () => {
      this.updateLiquidityPercent();
    });

    // Initialize liquidity slider
    this.updateLiquidityPercent();
  }

  private async fetchSymbolInfo() {
    try {
      console.log('[Client] Fetching symbol info from backend...');
      const response = await fetch('/api/symbol-info?symbol=' + this.symbol);

      if (response.ok) {
        this.symbolInfo = await response.json();
        console.log('[Client] Symbol info received:', this.symbolInfo);

        if (this.symbolInfo && this.symbolInfo.tickSize) {
          this.groupingLevels = generateGroupingLevels(this.symbolInfo.tickSize);
          this.updateGroupingSelect();
          console.log('[Client] Grouping levels generated:', this.groupingLevels);
        } else {
          throw new Error('Invalid symbol info received');
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('[Client] Failed to fetch symbol info:', error);
      // Use default grouping levels as fallback
      this.groupingLevels = [
        { value: 0.01, label: '0.01' },
        { value: 0.1, label: '0.1' },
        { value: 1, label: '1' },
        { value: 10, label: '10' }
      ];
      this.updateGroupingSelect();
      console.log('[Client] Using default grouping levels');
    }
  }

  private updateGroupingSelect() {
    this.groupingSelect.innerHTML = '';
    this.groupingLevels.forEach((level, index) => {
      const option = document.createElement('option');
      option.value = index.toString();
      option.textContent = level.label;
      this.groupingSelect.appendChild(option);
    });
  }

  private updateGrouping() {
    // Пересчитываем данные с новой группировкой
    if (this.lastOrderBookData) {
      this.processOrderBookData(this.lastOrderBookData);
    }
  }

  private updateLiquidityPercent() {
    const liquidityLevels = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20];
    const sliderValue = parseInt(this.liquiditySlider.value);
    this.currentLiquidityPercent = liquidityLevels[sliderValue];
    this.liquidityValue.textContent = `${this.currentLiquidityPercent}%`;

    // Перерендерим данные с новым процентом ликвидности
    if (this.lastOrderBookData) {
      this.processOrderBookData(this.lastOrderBookData);
    }
  }

  private initializeRenderer() {
    // Создаем HTML renderer вместо Canvas
    this.renderer = new HTMLOrderBookRenderer();
  }

  private connect() {
    if (this.isConnecting || (this.ws && this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.isConnecting = true;
    this.updateStatus('connecting', 'Connecting...');

    try {
      // Use the correct WebSocket URL for our server
      const wsUrl = 'ws://localhost:8080';
      
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[Client] Connected to WebSocket server');
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        this.reconnectDelay = 1000;
        this.updateStatus('connected', 'Connected');
        this.hideLoading();
        
        // Subscribe to orderbook updates
        this.subscribe();

        // Start ping monitoring
        this.startPingMonitoring();
      };

      this.ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          this.handleMessage(message);
        } catch (error) {
          console.error('[Client] Error parsing message:', error);
        }
      };

      this.ws.onclose = (event) => {
        console.log(`[Client] WebSocket closed: ${event.code} ${event.reason}`);
        this.isConnecting = false;
        this.updateStatus('disconnected', 'Disconnected');
        
        if (event.code !== 1000) { // Not a normal closure
          this.scheduleReconnect();
        }
      };

      this.ws.onerror = (error) => {
        console.error('[Client] WebSocket error:', error);
        this.isConnecting = false;
        this.showError('Connection error');
      };

    } catch (error) {
      console.error('[Client] Error creating WebSocket:', error);
      this.isConnecting = false;
      this.showError('Failed to connect');
      this.scheduleReconnect();
    }
  }

  private handleMessage(message: WebSocketMessage) {
    switch (message.type) {
      case 'connected':
        console.log('[Client] Server connection confirmed');
        break;

      case 'orderbook_delta':
        if (message.data) {
          this.processOrderBookData(message.data);
        }
        break;

      case 'batch_update':
        if (message.data && Array.isArray(message.data)) {
          // Process the latest update in the batch
          const latestUpdate = message.data[message.data.length - 1];
          if (latestUpdate && latestUpdate.type === 'orderbook_delta') {
            this.processOrderBookData(latestUpdate.data);
          }
        }
        break;

      case 'error':
        console.error('[Client] Server error:', message.error);
        this.showError(message.error || 'Server error');
        break;

      case 'subscribed':
        console.log('[Client] Subscribed to:', message.data?.subscription);
        break;

      case 'pong':
        this.handlePongResponse(message);
        break;

      default:
        console.log('[Client] Unknown message type:', message.type);
    }
  }

  private processOrderBookData(data: any) {
    if (!data || !data.bids || !data.asks) return;

    // Сохраняем данные для повторного использования при изменении ликвидности
    this.lastOrderBookData = data;

    // Get current grouping level
    const groupingLevel = this.groupingLevels[this.currentGroupingIndex] || { value: 0.01, label: '0.01' };

    // Apply grouping to bids and asks
    const groupedBids = groupOrderBookLevels(data.bids, groupingLevel, true);
    const groupedAsks = groupOrderBookLevels(data.asks, groupingLevel, false);

    // Calculate metrics
    const metrics = calculateOrderBookMetrics(groupedBids, groupedAsks, undefined, undefined, this.currentLiquidityPercent);

    // Prepare enhanced data for renderer
    const enhancedData = {
      ...data,
      bids: groupedBids,
      asks: groupedAsks,
      metrics,
      groupingLevel,
      symbolInfo: this.symbolInfo
    };

    this.renderer.updateData(enhancedData);
  }

  private subscribe() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const subscribeMessage = {
        type: 'subscribe',
        data: {
          symbol: this.symbol,
          stream: 'depth'
        }
      };

      this.ws.send(JSON.stringify(subscribeMessage));
      console.log(`[Client] Subscribed to ${this.symbol} orderbook`);
    }
  }

  private scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this.showError('Max reconnection attempts reached');
      return;
    }

    this.reconnectAttempts++;
    const delay = Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1), 30000);
    
    this.updateStatus('reconnecting', `Reconnecting in ${Math.ceil(delay / 1000)}s...`);
    
    setTimeout(() => {
      this.connect();
    }, delay);
  }

  private updateStatus(status: 'connecting' | 'connected' | 'disconnected' | 'reconnecting', text: string) {
    this.statusText.textContent = text;
    
    this.statusDot.className = 'status-dot';
    if (status === 'connected') {
      this.statusDot.classList.add('connected');
    }
  }

  private showLoading() {
    this.loadingElement.style.display = 'block';
  }

  private hideLoading() {
    this.loadingElement.style.display = 'none';
  }

  private showError(message: string) {
    this.errorElement.textContent = message;
    this.errorElement.style.display = 'block';
    
    // Auto-hide error after 5 seconds
    setTimeout(() => {
      this.errorElement.style.display = 'none';
    }, 5000);
  }

  private handleResize() {
    const newWidth = window.innerWidth;
    const newHeight = window.innerHeight - 60; // Account for header
    this.renderer.resize(newWidth, newHeight);
  }

  // Public methods for external control
  public changeSymbol(symbol: string) {
    this.symbol = symbol.toUpperCase();
    
    // Update UI
    document.querySelector('.symbol')!.textContent = symbol.replace('USDT', '/USDT');
    
    // Resubscribe if connected
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.subscribe();
    }
  }

  public disconnect() {
    this.stopPingMonitoring();
    if (this.ws) {
      this.ws.close(1000, 'Client disconnect');
    }
  }

  public getStatus() {
    return {
      connected: this.ws?.readyState === WebSocket.OPEN,
      reconnectAttempts: this.reconnectAttempts,
      symbol: this.symbol
    };
  }

  // Performance monitoring methods
  private startPingMonitoring() {
    // Send ping every 1 second for more frequent measurements
    this.pingInterval = window.setInterval(() => {
      this.sendPing();
    }, 1000);
  }

  private sendPing() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.lastPingTime = performance.now();
      const pingMessage = {
        type: 'ping',
        timestamp: this.lastPingTime
      };
      this.ws.send(JSON.stringify(pingMessage));
    }
  }

  private handlePongResponse(message: WebSocketMessage) {
    if (message.timestamp) {
      const currentTime = performance.now();
      const pingTime = currentTime - message.timestamp;

      // Update ping history
      this.pingHistory.push(pingTime);
      if (this.pingHistory.length > this.maxPingHistory) {
        this.pingHistory.shift();
      }

      // Update ping display
      this.updatePingDisplay(pingTime);
    }
  }

  private updatePingDisplay(pingTime: number) {
    const pingValue = document.querySelector('.ping-value');

    if (pingValue) {
      // Use requestAnimationFrame for smooth updates
      requestAnimationFrame(() => {
        pingValue.textContent = `${Math.round(pingTime)} ms`;

        // Color code based on ping
        if (pingTime < 50) {
          pingValue.className = 'ping-value ping-good';
        } else if (pingTime < 100) {
          pingValue.className = 'ping-value ping-medium';
        } else {
          pingValue.className = 'ping-value ping-bad';
        }
      });
    }
  }

  private stopPingMonitoring() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }
}

// Exchange selector functionality
class ExchangeSelector {
  private selector: HTMLSelectElement;
  private currentExchange: string = 'binance';

  constructor(private app: OrderBookClient) {
    this.selector = document.getElementById('exchange-selector') as HTMLSelectElement;
    this.initializeEventListeners();
    this.setCurrentExchange();
  }

  private initializeEventListeners() {
    this.selector.addEventListener('change', (e) => {
      const selectedExchange = (e.target as HTMLSelectElement).value;
      this.switchToExchange(selectedExchange);
    });
  }

  private setCurrentExchange() {
    // Determine current exchange from URL or default to binance
    const hostname = window.location.hostname;
    const port = window.location.port;

    // Map ports to exchanges
    const portToExchange: { [key: string]: string } = {
      '3001': 'binance',
      '3002': 'bingx',
      '3003': 'bitget',
      '3004': 'bitmart',
      '3005': 'bybit',
      '3006': 'coinbase',
      '3007': 'gateio',
      '3008': 'htx',
      '3009': 'kraken',
      '3010': 'kucoin',
      '3011': 'lbank',
      '3012': 'mexc',
      '3013': 'okx',
      '3014': 'whitebit'
    };

    this.currentExchange = portToExchange[port] || 'binance';
    this.selector.value = this.currentExchange;
  }

  private switchToExchange(exchangeName: string) {
    if (exchangeName === this.currentExchange) {
      return;
    }

    // Map exchange names to ports
    const exchangeToPort: { [key: string]: string } = {
      'binance': '3001',
      'bingx': '3002',
      'bitget': '3003',
      'bitmart': '3004',
      'bybit': '3005',
      'coinbase': '3006',
      'gateio': '3007',
      'htx': '3008',
      'kraken': '3009',
      'kucoin': '3010',
      'lbank': '3011',
      'mexc': '3012',
      'okx': '3013',
      'whitebit': '3014'
    };

    const targetPort = exchangeToPort[exchangeName];
    if (targetPort) {
      const currentUrl = new URL(window.location.href);
      currentUrl.port = targetPort;
      window.location.href = currentUrl.toString();
    }
  }
}

// Symbol search functionality
class SymbolSearch {
  private searchInput: HTMLInputElement;
  private dropdown: HTMLElement;
  private currentSymbolElement: HTMLElement;
  private searchTimeout: number | null = null;
  private isDropdownVisible = false;

  constructor(private app: OrderBookClient) {
    this.searchInput = document.getElementById('symbol-search-input') as HTMLInputElement;
    this.dropdown = document.getElementById('symbol-search-dropdown') as HTMLElement;
    this.currentSymbolElement = document.getElementById('current-symbol') as HTMLElement;

    this.initializeEventListeners();
  }

  private initializeEventListeners() {
    // Search input events
    this.searchInput.addEventListener('input', (e) => {
      const query = (e.target as HTMLInputElement).value.trim();
      this.handleSearch(query);
    });

    this.searchInput.addEventListener('focus', () => {
      if (this.searchInput.value.trim()) {
        this.showDropdown();
      }
    });

    this.searchInput.addEventListener('blur', () => {
      // Delay hiding to allow clicking on dropdown items
      setTimeout(() => this.hideDropdown(), 150);
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!this.searchInput.contains(e.target as Node) && !this.dropdown.contains(e.target as Node)) {
        this.hideDropdown();
      }
    });
  }

  private async handleSearch(query: string) {
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }

    if (!query) {
      this.hideDropdown();
      return;
    }

    this.searchTimeout = window.setTimeout(async () => {
      try {
        const response = await fetch(`/api/symbols/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();

        if (data.symbols && data.symbols.length > 0) {
          this.renderSearchResults(data.symbols);
          this.showDropdown();
        } else {
          this.hideDropdown();
        }
      } catch (error) {
        console.error('Error searching symbols:', error);
        this.hideDropdown();
      }
    }, 300);
  }

  private renderSearchResults(symbols: any[]) {
    this.dropdown.innerHTML = symbols.map(symbol => `
      <div class="symbol-search-item" data-symbol="${symbol.symbol}">
        <span class="symbol-search-symbol">${symbol.symbol}</span>
        <span class="symbol-search-pair">${symbol.baseAsset}/${symbol.quoteAsset}</span>
      </div>
    `).join('');

    // Add click handlers to items
    this.dropdown.querySelectorAll('.symbol-search-item').forEach(item => {
      item.addEventListener('click', () => {
        const symbol = item.getAttribute('data-symbol');
        if (symbol) {
          this.selectSymbol(symbol);
        }
      });
    });
  }

  private async selectSymbol(symbol: string) {
    try {
      // Call the backend to change symbol
      const response = await fetch('/api/symbol/change', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ symbol }),
      });

      const result = await response.json();

      if (result.success) {
        // Update UI
        this.currentSymbolElement.textContent = symbol.replace(/USDT$/, '/USDT');
        this.searchInput.value = '';
        this.hideDropdown();

        // Update the app's symbol
        this.app.changeSymbol(symbol);

        // Show success message
        this.showMessage(`Symbol changed to ${symbol}`, 'success');
      } else {
        this.showMessage(result.error || 'Failed to change symbol', 'error');
      }
    } catch (error) {
      console.error('Error changing symbol:', error);
      this.showMessage('Failed to change symbol', 'error');
    }
  }

  private showDropdown() {
    this.dropdown.classList.add('show');
    this.isDropdownVisible = true;
  }

  private hideDropdown() {
    this.dropdown.classList.remove('show');
    this.isDropdownVisible = false;
  }

  private showMessage(message: string, type: 'success' | 'error') {
    // Create a temporary message element
    const messageEl = document.createElement('div');
    messageEl.textContent = message;
    messageEl.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 10px 15px;
      border-radius: 4px;
      color: white;
      font-size: 12px;
      z-index: 10000;
      background: ${type === 'success' ? '#0ecb81' : '#f6465d'};
    `;

    document.body.appendChild(messageEl);

    setTimeout(() => {
      document.body.removeChild(messageEl);
    }, 3000);
  }
}

// Initialize the application
const app = new OrderBookClient();

// Initialize exchange selector and symbol search
const exchangeSelector = new ExchangeSelector(app);
const symbolSearch = new SymbolSearch(app);

// Expose app to global scope for debugging
(window as any).orderBookApp = app;
(window as any).exchangeSelector = exchangeSelector;
(window as any).symbolSearch = symbolSearch;

// Handle page unload
window.addEventListener('beforeunload', () => {
  app.disconnect();
});
