// Local types and utilities
interface OrderBookLevel {
  price: string;
  quantity: string;
}

interface SymbolInfo {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  tickSize: string;
  stepSize: string;
  minNotional: string;
}

interface GroupingLevel {
  value: number;
  label: string;
}

interface OrderBookMetrics {
  totalBidsVolume: number;
  totalAsksVolume: number;
  totalBidsValue: number;
  totalAsksValue: number;
  averageExecutionPrice: number;
  volumeAtPlusTwo: number;
  volumeAtMinusTwo: number;
  currentPrice: number;
}

interface RendererConfig {
  width: number;
  height: number;
  maxLevels: number;
  priceDecimals: number;
  quantityDecimals: number;
  animationDuration: number;
  groupingLevel: GroupingLevel;
  showMetrics: boolean;
  colors: {
    background: string;
    bid: string;
    ask: string;
    text: string;
    border: string;
    highlight: string;
    cursor: string;
    metrics: string;
  };
}

interface OrderBookState {
  connected: boolean;
  symbol: string;
  symbolInfo?: SymbolInfo;
  lastUpdate: number;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  spreadPercent: number;
  metrics: OrderBookMetrics;
  cursorPosition?: number;
  groupingLevel: GroupingLevel;
}

interface OrderBookData {
  symbol: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread?: number;
  spreadPercent?: number;
  metrics: OrderBookMetrics;
  groupingLevel: GroupingLevel;
  symbolInfo?: SymbolInfo;
}

// Utility functions
function formatNumber(value: number | string, maxDecimals: number = 8): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  const formatted = num.toFixed(maxDecimals);
  return formatted.replace(/\.?0+$/, '');
}

function formatLargeNumber(value: number): string {
  if (value >= 1e9) {
    return formatNumber(value / 1e9, 2) + 'B';
  } else if (value >= 1e6) {
    return formatNumber(value / 1e6, 2) + 'M';
  } else if (value >= 1e3) {
    return formatNumber(value / 1e3, 2) + 'K';
  }
  return formatNumber(value, 2);
}

function easeInOutCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function lerp(start: number, end: number, t: number): number {
  return start + (end - start) * t;
}

interface OrderBookData {
  symbol: string;
  symbolInfo?: SymbolInfo;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  spreadPercent: number;
  timestamp: number;
  metrics: OrderBookMetrics;
  cursorPosition?: number;
  groupingLevel: GroupingLevel;
}

interface AnimatedLevel {
  price: string;
  quantity: string;
  targetQuantity: string;
  animationStart: number;
  isNew: boolean;
  isRemoving: boolean;
}

export class OrderBookRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private config: RendererConfig;
  private data: OrderBookData | null = null;
  private animatedBids: Map<string, AnimatedLevel> = new Map();
  private animatedAsks: Map<string, AnimatedLevel> = new Map();
  private lastRenderTime = 0;
  private animationFrameId: number | null = null;
  private rowHeight = 20;
  private headerHeight = 60; // Increased for grouping controls
  private spreadHeight = 30;
  private metricsHeight = 80; // Height for metrics display
  private maxQuantity = 0;
  private cursorPosition: number | null = null;
  private mouseY = 0;
  private isMouseOver = false;

  constructor(canvas: HTMLCanvasElement, config: Partial<RendererConfig> = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    
    this.config = {
      width: 400,
      height: 700, // Increased for metrics
      maxLevels: 25,
      priceDecimals: 2,
      quantityDecimals: 4,
      animationDuration: 300,
      groupingLevel: { value: 0.01, label: '0.01' },
      showMetrics: true,
      colors: {
        background: '#0b0e11',
        bid: '#0ecb81',
        ask: '#f6465d',
        text: '#eaecef',
        border: '#2b3139',
        highlight: '#f0b90b',
        cursor: '#f0b90b',
        metrics: '#848e9c'
      },
      ...config
    };

    this.setupCanvas();
    this.setupEventListeners();
    this.startRenderLoop();
  }

  private setupCanvas() {
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = this.config.width * dpr;
    this.canvas.height = this.config.height * dpr;
    this.canvas.style.width = `${this.config.width}px`;
    this.canvas.style.height = `${this.config.height}px`;
    this.ctx.scale(dpr, dpr);

    // Set font
    this.ctx.font = '12px "SF Mono", "Monaco", "Inconsolata", "Roboto Mono", monospace';
    this.ctx.textAlign = 'left';
    this.ctx.textBaseline = 'middle';
  }

  private setupEventListeners() {
    this.canvas.addEventListener('mousemove', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      this.mouseY = e.clientY - rect.top;
      this.updateCursorPosition();
    });

    this.canvas.addEventListener('mouseenter', () => {
      this.isMouseOver = true;
    });

    this.canvas.addEventListener('mouseleave', () => {
      this.isMouseOver = false;
      this.cursorPosition = null;
    });
  }

  private updateCursorPosition() {
    if (!this.data || !this.isMouseOver) {
      this.cursorPosition = null;
      return;
    }

    const bidsStartY = this.headerHeight;
    const spreadY = bidsStartY + (this.config.maxLevels * this.rowHeight);
    const asksStartY = spreadY + this.spreadHeight;

    if (this.mouseY >= bidsStartY && this.mouseY < spreadY) {
      // Mouse is over bids
      const bidIndex = Math.floor((this.mouseY - bidsStartY) / this.rowHeight);
      if (bidIndex >= 0 && bidIndex < this.data.bids.length) {
        this.cursorPosition = bidIndex;
      }
    } else {
      this.cursorPosition = null;
    }
  }

  updateData(data: OrderBookData) {
    this.data = data;
    this.updateAnimations();
    this.calculateMaxQuantity();
    this.render(); // Автоматически перерисовываем после обновления данных
  }

  private updateAnimations() {
    if (!this.data) return;

    const now = Date.now();

    // Update bid animations
    this.updateLevelAnimations(this.data.bids, this.animatedBids, now);
    
    // Update ask animations
    this.updateLevelAnimations(this.data.asks, this.animatedAsks, now);
  }

  private updateLevelAnimations(
    levels: OrderBookLevel[], 
    animatedLevels: Map<string, AnimatedLevel>, 
    now: number
  ) {
    const currentPrices = new Set(levels.map(l => l.price));
    
    // Mark removed levels for animation
    for (const [price, animated] of animatedLevels) {
      if (!currentPrices.has(price) && !animated.isRemoving) {
        animated.isRemoving = true;
        animated.targetQuantity = '0';
        animated.animationStart = now;
      }
    }

    // Update or add levels
    levels.forEach(level => {
      const existing = animatedLevels.get(level.price);
      
      if (existing) {
        // Update existing level
        if (existing.targetQuantity !== level.quantity) {
          existing.targetQuantity = level.quantity;
          existing.animationStart = now;
          existing.isRemoving = false;
        }
      } else {
        // Add new level
        animatedLevels.set(level.price, {
          price: level.price,
          quantity: '0',
          targetQuantity: level.quantity,
          animationStart: now,
          isNew: true,
          isRemoving: false
        });
      }
    });

    // Remove completed animations
    for (const [price, animated] of animatedLevels) {
      if (animated.isRemoving && 
          now - animated.animationStart > this.config.animationDuration) {
        animatedLevels.delete(price);
      }
    }
  }

  private calculateMaxQuantity() {
    if (!this.data) return;

    let max = 0;
    [...this.data.bids, ...this.data.asks].forEach(level => {
      const qty = parseFloat(level.quantity);
      if (qty > max) max = qty;
    });
    
    this.maxQuantity = max;
  }

  private startRenderLoop() {
    const render = (timestamp: number) => {
      this.lastRenderTime = timestamp;
      this.render();
      this.animationFrameId = requestAnimationFrame(render);
    };
    
    this.animationFrameId = requestAnimationFrame(render);
  }

  private render() {
    this.clearCanvas();

    if (!this.data) {
      this.renderLoadingState();
      return;
    }

    this.renderHeader();
    this.renderOrderBook();
    this.renderSpread();
    this.renderMetrics();
  }

  private clearCanvas() {
    this.ctx.fillStyle = this.config.colors.background;
    this.ctx.fillRect(0, 0, this.config.width, this.config.height);
  }

  private renderLoadingState() {
    this.ctx.fillStyle = this.config.colors.text;
    this.ctx.textAlign = 'center';
    this.ctx.fillText(
      'Loading orderbook...', 
      this.config.width / 2, 
      this.config.height / 2
    );
    this.ctx.textAlign = 'left';
  }

  private renderHeader() {
    // Header background
    this.ctx.fillStyle = this.config.colors.border;
    this.ctx.fillRect(0, 0, this.config.width, this.headerHeight);

    // Symbol and grouping info
    if (this.data) {
      this.ctx.fillStyle = this.config.colors.text;
      this.ctx.font = 'bold 14px "SF Mono", monospace';
      this.ctx.fillText(`${this.data.symbol} Order Book`, 10, 20);

      this.ctx.font = '11px "SF Mono", monospace';
      this.ctx.fillStyle = this.config.colors.metrics;
      this.ctx.fillText(`Grouping: ${this.data.groupingLevel.label}`, 10, 35);
    }

    // Column headers
    this.ctx.fillStyle = this.config.colors.text;
    this.ctx.font = '11px "SF Mono", monospace';

    const priceX = 10;
    const quantityX = this.config.width / 2;
    const totalX = this.config.width - 80;

    this.ctx.fillText('Price (USDT)', priceX, this.headerHeight - 10);
    this.ctx.fillText('Amount (BTC)', quantityX, this.headerHeight - 10);
    this.ctx.fillText('Total', totalX, this.headerHeight - 10);

    this.ctx.font = '12px "SF Mono", monospace';
  }

  private renderOrderBook() {
    const startY = this.headerHeight;
    const askHeight = this.config.maxLevels * this.rowHeight;
    const bidStartY = startY + askHeight + this.spreadHeight;

    // Render asks (top half, reversed order)
    this.renderSide(
      Array.from(this.animatedAsks.values()).reverse(),
      startY,
      this.config.colors.ask,
      'ask'
    );

    // Render bids (bottom half)
    this.renderSide(
      Array.from(this.animatedBids.values()),
      bidStartY,
      this.config.colors.bid,
      'bid'
    );
  }

  private renderSide(
    levels: AnimatedLevel[],
    startY: number,
    color: string,
    side: 'bid' | 'ask'
  ) {
    const now = this.lastRenderTime;

    // Для asks нужно рассчитать кумулятивные суммы в правильном порядке (от дешевых к дорогим)
    const levelsToRender = levels.slice(0, this.config.maxLevels);
    let cumulativeTotals: number[] = [];

    if (side === 'ask') {
      // Для asks: рассчитываем кумулятивные суммы в обратном порядке (от дешевых к дорогим)
      let cumulativeTotal = 0;
      const reversedLevels = [...levelsToRender].reverse();
      const reversedTotals: number[] = [];

      reversedLevels.forEach((level) => {
        const progress = Math.min(
          (now - level.animationStart) / this.config.animationDuration,
          1
        );
        const easeProgress = easeInOutCubic(progress);
        const currentQty = this.interpolateQuantity(
          level.quantity,
          level.targetQuantity,
          easeProgress
        );
        cumulativeTotal += parseFloat(currentQty);
        reversedTotals.push(cumulativeTotal);
      });

      // Реверсим обратно для соответствия порядку отображения
      cumulativeTotals = reversedTotals.reverse();
    } else {
      // Для bids: рассчитываем кумулятивные суммы в порядке отображения (от дорогих к дешевым)
      let cumulativeTotal = 0;
      cumulativeTotals = levelsToRender.map((level) => {
        const progress = Math.min(
          (now - level.animationStart) / this.config.animationDuration,
          1
        );
        const easeProgress = easeInOutCubic(progress);
        const currentQty = this.interpolateQuantity(
          level.quantity,
          level.targetQuantity,
          easeProgress
        );
        cumulativeTotal += parseFloat(currentQty);
        return cumulativeTotal;
      });
    }

    levelsToRender.forEach((level, index) => {
      const y = startY + index * this.rowHeight;

      // Check if this is the cursor position
      const isCursor = side === 'bid' && this.cursorPosition === index;

      // Calculate animated quantity
      const progress = Math.min(
        (now - level.animationStart) / this.config.animationDuration,
        1
      );
      const easeProgress = easeInOutCubic(progress);

      const currentQty = this.interpolateQuantity(
        level.quantity,
        level.targetQuantity,
        easeProgress
      );

      level.quantity = currentQty.toString();

      this.renderLevel(level, y, color, side, cumulativeTotals[index], isCursor);
    });
  }

  private renderLevel(
    level: AnimatedLevel,
    y: number,
    color: string,
    side: 'bid' | 'ask',
    cumulativeTotal: number,
    isCursor: boolean = false
  ) {
    const quantity = parseFloat(level.quantity);
    const price = parseFloat(level.price);

    if (quantity <= 0) return;

    // Calculate bar width based on quantity (more prominent bars)
    const barWidth = this.maxQuantity > 0
      ? (quantity / this.maxQuantity) * (this.config.width * 0.6)
      : 0;

    // Render quantity bar with gradient effect
    const gradient = this.ctx.createLinearGradient(0, y, barWidth, y);
    gradient.addColorStop(0, color + '40'); // 25% opacity at start
    gradient.addColorStop(1, color + '10'); // 6% opacity at end

    this.ctx.fillStyle = gradient;
    const barX = side === 'bid' ? this.config.width - barWidth : 0;
    this.ctx.fillRect(barX, y, barWidth, this.rowHeight);

    // Add subtle border to bars
    this.ctx.strokeStyle = color + '60';
    this.ctx.lineWidth = 0.5;
    this.ctx.strokeRect(barX, y, barWidth, this.rowHeight);

    // Highlight cursor position
    if (isCursor) {
      this.ctx.fillStyle = this.config.colors.cursor + '20';
      this.ctx.fillRect(0, y, this.config.width, this.rowHeight);
      this.ctx.strokeStyle = this.config.colors.cursor;
      this.ctx.lineWidth = 2;
      this.ctx.strokeRect(0, y, this.config.width, this.rowHeight);
    }

    // Render text with better positioning
    const priceX = 10;
    const quantityX = this.config.width * 0.4;
    const totalX = this.config.width - 100;

    // Price (colored and bold, formatted without trailing zeros)
    this.ctx.fillStyle = color;
    this.ctx.font = 'bold 12px "SF Mono", monospace';
    this.ctx.fillText(
      formatNumber(price, this.config.priceDecimals),
      priceX,
      y + this.rowHeight / 2
    );

    // Quantity (normal weight, formatted)
    this.ctx.font = '12px "SF Mono", monospace';
    this.ctx.fillStyle = this.config.colors.text;
    this.ctx.fillText(
      formatNumber(quantity, this.config.quantityDecimals),
      quantityX,
      y + this.rowHeight / 2
    );

    // Cumulative total (dimmed, formatted with K/M/B suffixes)
    this.ctx.fillStyle = this.config.colors.text + '80';
    this.ctx.fillText(
      formatLargeNumber(cumulativeTotal * price),
      totalX,
      y + this.rowHeight / 2
    );

    // Highlight new levels with glow effect
    if (level.isNew && (this.lastRenderTime - level.animationStart) < 1000) {
      this.ctx.shadowColor = this.config.colors.highlight;
      this.ctx.shadowBlur = 10;
      this.ctx.strokeStyle = this.config.colors.highlight;
      this.ctx.lineWidth = 2;
      this.ctx.strokeRect(0, y, this.config.width, this.rowHeight);
      this.ctx.shadowBlur = 0;
    }
  }

  private renderSpread() {
    if (!this.data) return;

    const y = this.headerHeight + this.config.maxLevels * this.rowHeight;

    // Background
    this.ctx.fillStyle = this.config.colors.border;
    this.ctx.fillRect(0, y, this.config.width, this.spreadHeight);

    // Spread text and average execution price
    this.ctx.fillStyle = this.config.colors.text;
    this.ctx.textAlign = 'center';
    this.ctx.font = '11px "SF Mono", monospace';

    const spreadPercent = this.data.spreadPercent || 0;
    const spreadText = `Spread: ${formatNumber(this.data.spread || 0, this.config.priceDecimals)} (${spreadPercent.toFixed(2)}%)`;
    this.ctx.fillText(spreadText, this.config.width / 2, y + 10);

    // Show average execution price if cursor is positioned
    if (this.cursorPosition !== null && this.data.metrics.averageExecutionPrice > 0) {
      this.ctx.fillStyle = this.config.colors.cursor;
      const avgPriceText = `Avg.Price: ≈ ${formatNumber(this.data.metrics.averageExecutionPrice)}`;
      this.ctx.fillText(avgPriceText, this.config.width / 2, y + 22);
    }

    this.ctx.textAlign = 'left';
    this.ctx.font = '12px "SF Mono", monospace';
  }

  private renderMetrics() {
    if (!this.data || !this.config.showMetrics) return;

    const startY = this.config.height - this.metricsHeight;

    // Background
    this.ctx.fillStyle = this.config.colors.border;
    this.ctx.fillRect(0, startY, this.config.width, this.metricsHeight);

    // Metrics text
    this.ctx.fillStyle = this.config.colors.metrics;
    this.ctx.font = '10px "SF Mono", monospace';

    const metrics = this.data.metrics;
    const leftX = 10;
    const rightX = this.config.width / 2 + 10;

    // Left column
    this.ctx.fillText(`Sum BTC: ${formatNumber(metrics.totalBidsVolume + metrics.totalAsksVolume)}`, leftX, startY + 15);
    this.ctx.fillText(`Sum USDT: ${formatLargeNumber(metrics.totalBidsValue + metrics.totalAsksValue)}`, leftX, startY + 30);
    this.ctx.fillText(`+2% Volume: ${formatLargeNumber(metrics.volumeAtPlusTwo)}`, leftX, startY + 45);
    this.ctx.fillText(`-2% Volume: ${formatLargeNumber(metrics.volumeAtMinusTwo)}`, leftX, startY + 60);

    // Right column
    this.ctx.fillText(`Bids: ${formatLargeNumber(metrics.totalBidsValue)} USDT`, rightX, startY + 15);
    this.ctx.fillText(`Asks: ${formatLargeNumber(metrics.totalAsksValue)} USDT`, rightX, startY + 30);
    this.ctx.fillText(`Current: ${formatNumber(metrics.currentPrice)}`, rightX, startY + 45);

    if (this.cursorPosition !== null && metrics.averageExecutionPrice > 0) {
      this.ctx.fillStyle = this.config.colors.cursor;
      this.ctx.fillText(`Avg Exec: ${formatNumber(metrics.averageExecutionPrice)}`, rightX, startY + 60);
    }

    this.ctx.font = '12px "SF Mono", monospace';
  }

  private interpolateQuantity(from: string, to: string, progress: number): number {
    const fromNum = parseFloat(from);
    const toNum = parseFloat(to);
    return lerp(fromNum, toNum, progress);
  }

  resize(width: number, height: number) {
    this.config.width = width;
    this.config.height = height;
    this.setupCanvas();
  }

  destroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }
}
