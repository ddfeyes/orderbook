
/**
 * Base OrderBook class - единый стандарт для всех бирж
 * Следует принципам Binance для сортировки и расчета спреда
 */
class BaseOrderBook {
  constructor(symbol) {
    this.symbol = symbol;
    this.bids = new Map(); // price -> quantity
    this.asks = new Map(); // price -> quantity
    this.lastUpdateId = 0;
    this.isInitialized = false;
  }

  /**
   * Получить снимок orderbook с правильной сортировкой
   * @param {number} limit - лимит записей
   * @returns {Object} Снимок orderbook
   */
  getSnapshot(limit = null) {
    // Sort bids by price descending (highest first) - стандарт Binance
    const sortedBids = Array.from(this.bids.entries())
      .sort(([a], [b]) => parseFloat(b) - parseFloat(a))
      .map(([price, quantity]) => ({ price, quantity }));

    // Sort asks by price ascending for spread calculation (lowest first)
    const sortedAsksForSpread = Array.from(this.asks.entries())
      .sort(([a], [b]) => parseFloat(a) - parseFloat(b))
      .map(([price, quantity]) => ({ price, quantity }));

    // Sort asks by price descending for display (highest first) - для CSS column-reverse
    const sortedAsksForDisplay = Array.from(this.asks.entries())
      .sort(([a], [b]) => parseFloat(b) - parseFloat(a))
      .map(([price, quantity]) => ({ price, quantity }));

    const bids = limit ? sortedBids.slice(0, limit) : sortedBids;
    const asks = limit ? sortedAsksForDisplay.slice(0, limit) : sortedAsksForDisplay;

    // Calculate spread using correct sorting (bestAsk = lowest ask price)
    const bestBid = bids.length > 0 ? parseFloat(bids[0].price) : 0;
    const bestAsk = sortedAsksForSpread.length > 0 ? parseFloat(sortedAsksForSpread[0].price) : 0;
    const spread = bestAsk > 0 && bestBid > 0 ? bestAsk - bestBid : 0;
    const spreadPercent = bestBid > 0 ? (spread / bestBid) * 100 : 0;

    return {
      symbol: this.symbol,
      lastUpdateId: this.lastUpdateId,
      timestamp: Date.now(),
      bids,
      asks,
      spread,
      spreadPercent,
      isInitialized: this.isInitialized
    };
  }

  /**
   * Получить лучшие bid и ask цены
   * @returns {Object} Лучшие цены
   */
  getBestPrices() {
    const snapshot = this.getSnapshot(1);
    return {
      bestBid: snapshot.bids.length > 0 ? parseFloat(snapshot.bids[0].price) : 0,
      bestAsk: snapshot.asks.length > 0 ? parseFloat(snapshot.asks[0].price) : 0,
      spread: snapshot.spread,
      spreadPercent: snapshot.spreadPercent
    };
  }

  /**
   * Обновить bid
   * @param {string} price - цена
   * @param {string} quantity - количество
   */
  updateBid(price, quantity) {
    const qty = parseFloat(quantity);
    if (qty === 0) {
      this.bids.delete(price);
    } else {
      this.bids.set(price, quantity);
    }
  }

  /**
   * Обновить ask
   * @param {string} price - цена
   * @param {string} quantity - количество
   */
  updateAsk(price, quantity) {
    const qty = parseFloat(quantity);
    if (qty === 0) {
      this.asks.delete(price);
    } else {
      this.asks.set(price, quantity);
    }
  }

  /**
   * Инициализировать orderbook снимком
   * @param {Object} snapshot - снимок данных
   */
  initializeSnapshot(snapshot) {
    this.bids.clear();
    this.asks.clear();
    
    if (snapshot.bids) {
      snapshot.bids.forEach(([price, quantity]) => {
        this.updateBid(price, quantity);
      });
    }
    
    if (snapshot.asks) {
      snapshot.asks.forEach(([price, quantity]) => {
        this.updateAsk(price, quantity);
      });
    }
    
    this.isInitialized = true;
  }

  /**
   * Получить статистику orderbook
   * @returns {Object} Статистика
   */
  getStats() {
    return {
      bidsCount: this.bids.size,
      asksCount: this.asks.size,
      isInitialized: this.isInitialized,
      lastUpdateId: this.lastUpdateId
    };
  }
}

module.exports = BaseOrderBook;
