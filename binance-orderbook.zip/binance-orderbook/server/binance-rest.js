const axios = require('axios');

class BinanceRestClient {
  constructor() {
    this.baseURL = 'https://api.binance.com';
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: 10000,
      headers: {
        'User-Agent': 'binance-orderbook/1.0.0'
      }
    });

    // Add request interceptor for logging
    this.client.interceptors.request.use(
      (config) => {
        console.log(`[REST] ${config.method?.toUpperCase()} ${config.url}`);
        return config;
      },
      (error) => {
        console.error('[REST] Request error:', error.message);
        return Promise.reject(error);
      }
    );

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        console.error('[REST] Response error:', error.message);
        if (error.response) {
          console.error('[REST] Status:', error.response.status);
          console.error('[REST] Data:', error.response.data);
        }
        return Promise.reject(error);
      }
    );
  }

  /**
   * Get exchange information including symbol details
   * @returns {Promise<Object>} Exchange info
   */
  async getExchangeInfo() {
    try {
      const response = await this.client.get('/api/v3/exchangeInfo');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get exchange info: ${error.message}`);
    }
  }

  /**
   * Get orderbook snapshot
   * @param {string} symbol - Trading pair symbol (e.g., 'BTCUSDT')
   * @param {number} limit - Number of price levels (5, 10, 20, 50, 100, 500, 1000, 5000)
   * @returns {Promise<Object>} Orderbook snapshot
   */
  async getOrderBookSnapshot(symbol, limit = 1000) {
    try {
      const validLimits = [5, 10, 20, 50, 100, 500, 1000, 5000];
      if (!validLimits.includes(limit)) {
        throw new Error(`Invalid limit. Must be one of: ${validLimits.join(', ')}`);
      }

      const response = await this.client.get('/api/v3/depth', {
        params: {
          symbol: symbol.toUpperCase(),
          limit: limit
        }
      });

      const data = response.data;
      
      // Validate response structure
      if (!data.lastUpdateId || !Array.isArray(data.bids) || !Array.isArray(data.asks)) {
        throw new Error('Invalid orderbook response structure');
      }

      // Convert string arrays to objects for easier handling
      const processedData = {
        lastUpdateId: data.lastUpdateId,
        bids: data.bids.map(([price, quantity]) => ({
          price: price,
          quantity: quantity
        })),
        asks: data.asks.map(([price, quantity]) => ({
          price: price,
          quantity: quantity
        }))
      };

      console.log(`[REST] Got orderbook snapshot for ${symbol}: ${processedData.bids.length} bids, ${processedData.asks.length} asks, lastUpdateId: ${processedData.lastUpdateId}`);
      
      return processedData;
    } catch (error) {
      throw new Error(`Failed to get orderbook snapshot for ${symbol}: ${error.message}`);
    }
  }

  /**
   * Get recent trades
   * @param {string} symbol - Trading pair symbol
   * @param {number} limit - Number of trades to return (max 1000)
   * @returns {Promise<Array>} Recent trades
   */
  async getRecentTrades(symbol, limit = 500) {
    try {
      const response = await this.client.get('/api/v3/trades', {
        params: {
          symbol: symbol.toUpperCase(),
          limit: Math.min(limit, 1000)
        }
      });

      return response.data;
    } catch (error) {
      throw new Error(`Failed to get recent trades for ${symbol}: ${error.message}`);
    }
  }

  /**
   * Get 24hr ticker statistics
   * @param {string} symbol - Trading pair symbol
   * @returns {Promise<Object>} 24hr ticker data
   */
  async get24hrTicker(symbol) {
    try {
      const response = await this.client.get('/api/v3/ticker/24hr', {
        params: {
          symbol: symbol.toUpperCase()
        }
      });

      return response.data;
    } catch (error) {
      throw new Error(`Failed to get 24hr ticker for ${symbol}: ${error.message}`);
    }
  }

  /**
   * Check if symbol exists and is active
   * @param {string} symbol - Trading pair symbol
   * @returns {Promise<boolean>} True if symbol is valid and active
   */
  async isValidSymbol(symbol) {
    try {
      const exchangeInfo = await this.getExchangeInfo();
      const symbolInfo = exchangeInfo.symbols.find(s => s.symbol === symbol.toUpperCase());
      return symbolInfo && symbolInfo.status === 'TRADING';
    } catch (error) {
      console.error(`Error checking symbol validity: ${error.message}`);
      return false;
    }
  }

  /**
   * Get symbol info including price and quantity precision
   * @param {string} symbol - Trading pair symbol
   * @returns {Promise<Object|null>} Symbol information or null if not found
   */
  async getSymbolInfo(symbol) {
    try {
      const exchangeInfo = await this.getExchangeInfo();
      const symbolInfo = exchangeInfo.symbols.find(s => s.symbol === symbol.toUpperCase());
      
      if (!symbolInfo) {
        return null;
      }

      // Extract precision info from filters
      const priceFilter = symbolInfo.filters.find(f => f.filterType === 'PRICE_FILTER');
      const lotSizeFilter = symbolInfo.filters.find(f => f.filterType === 'LOT_SIZE');
      const minNotionalFilter = symbolInfo.filters.find(f => f.filterType === 'NOTIONAL');

      return {
        symbol: symbolInfo.symbol,
        status: symbolInfo.status,
        baseAsset: symbolInfo.baseAsset,
        quoteAsset: symbolInfo.quoteAsset,
        pricePrecision: symbolInfo.quotePrecision,
        quantityPrecision: symbolInfo.baseAssetPrecision,
        tickSize: priceFilter ? priceFilter.tickSize : '0.01',
        stepSize: lotSizeFilter ? lotSizeFilter.stepSize : '0.00001',
        minNotional: minNotionalFilter ? minNotionalFilter.minNotional : '10'
      };
    } catch (error) {
      throw new Error(`Failed to get symbol info for ${symbol}: ${error.message}`);
    }
  }
}

module.exports = BinanceRestClient;
