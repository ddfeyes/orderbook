const WebSocket = require('ws');
const EventEmitter = require('events');

class BinanceWebSocketClient extends EventEmitter {
  constructor() {
    super();
    this.baseURL = 'wss://stream.binance.com:9443';
    this.ws = null;
    this.isConnected = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.reconnectDelay = 1000; // Start with 1 second
    this.maxReconnectDelay = 30000; // Max 30 seconds
    this.pingInterval = null;
    this.subscriptions = new Set();
    this.lastPongTime = Date.now();
  }

  /**
   * Connect to Binance WebSocket
   * @param {string} symbol - Trading pair symbol
   * @param {string} stream - Stream type (e.g., 'depth', 'depth@100ms')
   */
  connect(symbol, stream = 'depth') {
    const streamName = `${symbol.toLowerCase()}@${stream}`;
    const url = `${this.baseURL}/ws/${streamName}`;
    
    console.log(`[WS] Connecting to ${url}`);
    
    this.ws = new WebSocket(url);
    this.subscriptions.add(streamName);

    this.ws.on('open', () => {
      console.log('[WS] Connected to Binance WebSocket');
      this.isConnected = true;
      this.reconnectAttempts = 0;
      this.reconnectDelay = 1000;
      this.startPingPong();
      this.emit('connected');
    });

    this.ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        this.handleMessage(message);
      } catch (error) {
        console.error('[WS] Error parsing message:', error.message);
        this.emit('error', error);
      }
    });

    this.ws.on('close', (code, reason) => {
      console.log(`[WS] Connection closed: ${code} ${reason}`);
      this.isConnected = false;
      this.stopPingPong();
      this.emit('disconnected', { code, reason });
      
      if (code !== 1000) { // Not a normal closure
        this.scheduleReconnect();
      }
    });

    this.ws.on('error', (error) => {
      console.error('[WS] WebSocket error:', error.message);
      this.emit('error', error);
    });

    this.ws.on('pong', () => {
      this.lastPongTime = Date.now();
    });
  }

  /**
   * Handle incoming WebSocket messages
   * @param {Object} message - Parsed JSON message
   */
  handleMessage(message) {
    if (message.e === 'depthUpdate') {
      // Orderbook update
      const update = {
        eventType: message.e,
        eventTime: message.E,
        symbol: message.s,
        firstUpdateId: message.U,
        finalUpdateId: message.u,
        bids: message.b.map(([price, quantity]) => ({ price, quantity })),
        asks: message.a.map(([price, quantity]) => ({ price, quantity }))
      };
      
      this.emit('depthUpdate', update);
    } else if (message.e === 'trade') {
      // Trade update
      const trade = {
        eventType: message.e,
        eventTime: message.E,
        symbol: message.s,
        tradeId: message.t,
        price: message.p,
        quantity: message.q,
        buyerOrderId: message.b,
        sellerOrderId: message.a,
        tradeTime: message.T,
        isBuyerMaker: message.m
      };
      
      this.emit('trade', trade);
    } else {
      // Unknown message type
      console.log('[WS] Unknown message type:', message);
    }
  }

  /**
   * Start ping-pong mechanism to keep connection alive
   */
  startPingPong() {
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.ping();
        
        // Check if we received pong recently
        const timeSinceLastPong = Date.now() - this.lastPongTime;
        if (timeSinceLastPong > 60000) { // 1 minute without pong
          console.warn('[WS] No pong received for 1 minute, reconnecting...');
          this.reconnect();
        }
      }
    }, 30000); // Ping every 30 seconds
  }

  /**
   * Stop ping-pong mechanism
   */
  stopPingPong() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  /**
   * Schedule reconnection with exponential backoff
   */
  scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('[WS] Max reconnection attempts reached');
      this.emit('maxReconnectAttemptsReached');
      return;
    }

    this.reconnectAttempts++;
    const delay = Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1), this.maxReconnectDelay);
    
    console.log(`[WS] Scheduling reconnect attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
    
    setTimeout(() => {
      this.reconnect();
    }, delay);
  }

  /**
   * Reconnect to WebSocket
   */
  reconnect() {
    if (this.ws) {
      this.ws.removeAllListeners();
      if (this.ws.readyState === WebSocket.OPEN) {
        this.ws.close();
      }
    }

    // Get the first subscription to reconnect with
    const firstSubscription = Array.from(this.subscriptions)[0];
    if (firstSubscription) {
      const [symbol, stream] = firstSubscription.split('@');
      this.connect(symbol, stream);
    }
  }

  /**
   * Subscribe to additional streams (for multi-stream connections)
   * @param {string} symbol - Trading pair symbol
   * @param {string} stream - Stream type
   */
  subscribe(symbol, stream = 'depth') {
    const streamName = `${symbol.toLowerCase()}@${stream}`;
    
    if (this.subscriptions.has(streamName)) {
      console.log(`[WS] Already subscribed to ${streamName}`);
      return;
    }

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const subscribeMessage = {
        method: 'SUBSCRIBE',
        params: [streamName],
        id: Date.now()
      };
      
      this.ws.send(JSON.stringify(subscribeMessage));
      this.subscriptions.add(streamName);
      console.log(`[WS] Subscribed to ${streamName}`);
    } else {
      console.warn('[WS] Cannot subscribe: WebSocket not connected');
    }
  }

  /**
   * Unsubscribe from streams
   * @param {string} symbol - Trading pair symbol
   * @param {string} stream - Stream type
   */
  unsubscribe(symbol, stream = 'depth') {
    const streamName = `${symbol.toLowerCase()}@${stream}`;
    
    if (!this.subscriptions.has(streamName)) {
      console.log(`[WS] Not subscribed to ${streamName}`);
      return;
    }

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const unsubscribeMessage = {
        method: 'UNSUBSCRIBE',
        params: [streamName],
        id: Date.now()
      };
      
      this.ws.send(JSON.stringify(unsubscribeMessage));
      this.subscriptions.delete(streamName);
      console.log(`[WS] Unsubscribed from ${streamName}`);
    }
  }

  /**
   * Close WebSocket connection
   */
  close() {
    console.log('[WS] Closing WebSocket connection');
    this.stopPingPong();
    
    if (this.ws) {
      this.ws.close(1000, 'Client closing');
      this.ws = null;
    }
    
    this.isConnected = false;
    this.subscriptions.clear();
  }

  /**
   * Get connection status
   * @returns {Object} Connection status information
   */
  getStatus() {
    return {
      connected: this.isConnected,
      reconnectAttempts: this.reconnectAttempts,
      subscriptions: Array.from(this.subscriptions),
      readyState: this.ws ? this.ws.readyState : null
    };
  }
}

module.exports = BinanceWebSocketClient;
