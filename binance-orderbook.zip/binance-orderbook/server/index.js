const express = require('express');
const path = require('path');
const cors = require('cors');
const compression = require('compression');

const BinanceRestClient = require('./binance-rest');
const BinanceWebSocketClient = require('./binance-websocket');
const LocalOrderBook = require('./local-orderbook');
const WebSocketServer = require('./websocket-server');

class OrderBookService {
  constructor() {
    this.symbol = 'BTCUSDT';
    this.restClient = new BinanceRestClient();
    this.wsClient = new BinanceWebSocketClient();
    this.orderBook = new LocalOrderBook(this.symbol);
    this.wsServer = new WebSocketServer(8080);
    this.app = express();
    this.isInitialized = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;

    // Cache for symbol information
    this.symbolInfoCache = new Map();
    this.cacheExpiry = 24 * 60 * 60 * 1000; // 24 hours

    this.setupExpress();
    this.setupEventHandlers();
    this.initializeSymbolInfo();
  }

  setupExpress() {
    // Middleware
    this.app.use(compression());
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.static(path.join(__dirname, '../client')));



    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'ok',
        timestamp: Date.now(),
        orderbook: this.orderBook.getStats(),
        websocket: this.wsServer.getStats(),
        binanceConnection: this.wsClient.getStatus()
      });
    });

    // API endpoints
    this.app.get('/api/orderbook/:symbol', async (req, res) => {
      try {
        const { symbol } = req.params;
        const limit = parseInt(req.query.limit) || 5000;

        if (symbol.toUpperCase() === this.symbol) {
          const snapshot = this.orderBook.getSnapshot(limit);
          res.json(snapshot);
        } else {
          // Get snapshot from REST API for other symbols
          const snapshot = await this.restClient.getOrderBookSnapshot(symbol, Math.min(limit, 5000));
          res.json(snapshot);
        }
      } catch (error) {
        console.error('Error getting orderbook:', error.message);
        res.status(500).json({ error: error.message });
      }
    });

    // Get all available symbols
    this.app.get('/api/symbols', async (req, res) => {
      try {
        const exchangeInfo = await this.restClient.getExchangeInfo();
        const symbols = exchangeInfo.symbols
          .filter(s => s.status === 'TRADING')
          .map(s => ({
            symbol: s.symbol,
            baseAsset: s.baseAsset,
            quoteAsset: s.quoteAsset,
            status: s.status
          }));

        res.json({
          exchange: 'binance',
          symbols: symbols,
          count: symbols.length
        });
      } catch (error) {
        console.error('Error getting symbols:', error.message);
        res.status(500).json({ error: error.message });
      }
    });

    // Search symbols
    this.app.get('/api/symbols/search', async (req, res) => {
      try {
        const { q } = req.query;
        if (!q) {
          return res.status(400).json({ error: 'Query parameter "q" is required' });
        }

        const exchangeInfo = await this.restClient.getExchangeInfo();
        const query = q.toUpperCase();
        const symbols = exchangeInfo.symbols
          .filter(s => s.status === 'TRADING')
          .filter(s =>
            s.symbol.includes(query) ||
            s.baseAsset.includes(query) ||
            s.quoteAsset.includes(query)
          )
          .map(s => ({
            symbol: s.symbol,
            baseAsset: s.baseAsset,
            quoteAsset: s.quoteAsset,
            status: s.status
          }))
          .slice(0, 50); // Limit results

        res.json({
          exchange: 'binance',
          query: q,
          symbols: symbols,
          count: symbols.length
        });
      } catch (error) {
        console.error('Error searching symbols:', error.message);
        res.status(500).json({ error: error.message });
      }
    });

    // Change active symbol
    this.app.post('/api/symbol/change', async (req, res) => {
      try {
        const { symbol } = req.body;
        if (!symbol) {
          return res.status(400).json({ error: 'Symbol is required' });
        }

        // Validate symbol
        const isValid = await this.restClient.isValidSymbol(symbol);
        if (!isValid) {
          return res.status(400).json({ error: 'Invalid symbol' });
        }

        const oldSymbol = this.symbol;
        this.symbol = symbol.toUpperCase();

        // Close existing WebSocket connection
        this.wsClient.close();

        // Reset orderbook
        this.orderBook.reset();
        this.isInitialized = false;

        // Reinitialize with new symbol
        await this.initializeBinanceConnection();

        res.json({
          success: true,
          oldSymbol: oldSymbol,
          newSymbol: this.symbol,
          message: 'Symbol changed successfully'
        });
      } catch (error) {
        console.error('Error changing symbol:', error.message);
        res.status(500).json({ error: error.message });
      }
    });

    this.app.get('/api/symbol/:symbol/info', async (req, res) => {
      try {
        const { symbol } = req.params;
        const info = await this.restClient.getSymbolInfo(symbol);
        res.json(info);
      } catch (error) {
        console.error('Error getting symbol info:', error.message);
        res.status(500).json({ error: error.message });
      }
    });

    // Simplified endpoint for symbol info with caching
    this.app.get('/api/symbol-info', async (req, res) => {
      try {
        const symbol = req.query.symbol || this.symbol;
        const cachedInfo = this.getSymbolInfoFromCache(symbol);

        if (cachedInfo) {
          res.json(cachedInfo);
          return;
        }

        const info = await this.restClient.getSymbolInfo(symbol);
        if (info) {
          this.cacheSymbolInfo(symbol, info);
          res.json(info);
        } else {
          res.status(404).json({ error: 'Symbol not found' });
        }
      } catch (error) {
        console.error('Error getting symbol info:', error.message);
        res.status(500).json({ error: error.message });
      }
    });

    // Serve client app for all other routes
    this.app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, '../dist/index.html'));
    });
  }

  setupEventHandlers() {
    // OrderBook events
    this.orderBook.on('initialized', (snapshot) => {
      console.log(`[Service] OrderBook initialized for ${this.symbol}`);
      this.isInitialized = true;
      const symbolInfo = this.getSymbolInfoFromCache(this.symbol);
      this.wsServer.broadcastOrderBookUpdate(snapshot, symbolInfo);
    });

    this.orderBook.on('update', (update) => {
      if (this.isInitialized) {
        const snapshot = this.orderBook.getSnapshot(); // Send all levels (no limit)
        const symbolInfo = this.getSymbolInfoFromCache(this.symbol);
        this.wsServer.broadcastOrderBookUpdate(snapshot, symbolInfo);
      }
    });

    this.orderBook.on('sequenceGap', (gap) => {
      console.warn(`[Service] Sequence gap detected for ${this.symbol}:`, gap);
      this.reinitializeOrderBook();
    });

    this.orderBook.on('reset', () => {
      console.log(`[Service] OrderBook reset for ${this.symbol}`);
      this.isInitialized = false;
    });

    // Binance WebSocket events
    this.wsClient.on('connected', () => {
      console.log('[Service] Connected to Binance WebSocket');
      this.reconnectAttempts = 0;
    });

    this.wsClient.on('disconnected', (info) => {
      console.log('[Service] Disconnected from Binance WebSocket:', info);
      this.isInitialized = false;
      
      if (info.code !== 1000) {
        this.scheduleReconnect();
      }
    });

    this.wsClient.on('depthUpdate', (update) => {
      this.orderBook.applyUpdate(update);
    });

    this.wsClient.on('error', (error) => {
      console.error('[Service] Binance WebSocket error:', error.message);
    });

    this.wsClient.on('maxReconnectAttemptsReached', () => {
      console.error('[Service] Max reconnect attempts reached for Binance WebSocket');
      setTimeout(() => {
        this.initializeBinanceConnection();
      }, 60000); // Retry after 1 minute
    });

    // WebSocket Server events
    this.wsServer.on('started', () => {
      console.log('[Service] WebSocket server started');
    });

    this.wsServer.on('clientSubscribed', ({ subscription }) => {
      console.log(`[Service] Client subscribed to ${subscription}`);
    });

    this.wsServer.on('error', (error) => {
      console.error('[Service] WebSocket server error:', error.message);
    });
  }

  async initializeBinanceConnection() {
    try {
      console.log(`[Service] Initializing connection for ${this.symbol}`);
      
      // Validate symbol
      const isValid = await this.restClient.isValidSymbol(this.symbol);
      if (!isValid) {
        throw new Error(`Invalid symbol: ${this.symbol}`);
      }

      // Get initial snapshot
      console.log(`[Service] Getting initial snapshot for ${this.symbol}`);
      const snapshot = await this.restClient.getOrderBookSnapshot(this.symbol, 5000);
      
      // Initialize local orderbook
      this.orderBook.initializeFromSnapshot(snapshot);
      
      // Connect to WebSocket
      console.log(`[Service] Connecting to Binance WebSocket for ${this.symbol}`);
      this.wsClient.connect(this.symbol, 'depth@100ms');
      
    } catch (error) {
      console.error('[Service] Error initializing Binance connection:', error.message);
      this.scheduleReconnect();
    }
  }

  scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('[Service] Max reconnection attempts reached');
      return;
    }

    this.reconnectAttempts++;
    const delay = Math.min(5000 * Math.pow(2, this.reconnectAttempts - 1), 60000);
    
    console.log(`[Service] Scheduling reconnect attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
    
    setTimeout(() => {
      this.initializeBinanceConnection();
    }, delay);
  }

  async reinitializeOrderBook() {
    try {
      console.log(`[Service] Reinitializing orderbook for ${this.symbol}`);
      
      // Reset orderbook
      this.orderBook.reset();
      
      // Get fresh snapshot
      const snapshot = await this.restClient.getOrderBookSnapshot(this.symbol, 5000);
      this.orderBook.initializeFromSnapshot(snapshot);
      
    } catch (error) {
      console.error('[Service] Error reinitializing orderbook:', error.message);
      this.scheduleReconnect();
    }
  }

  async start() {
    try {
      console.log('[Service] Starting OrderBook service...');
      
      // Start WebSocket server
      this.wsServer.start();
      this.wsServer.startHeartbeat();
      
      // Initialize Binance connection
      await this.initializeBinanceConnection();
      
      // Start Express server
      const port = process.env.PORT || 3001;
      this.app.listen(port, () => {
        console.log(`[Service] HTTP server started on port ${port}`);
        console.log(`[Service] OrderBook service is ready!`);
      });
      
    } catch (error) {
      console.error('[Service] Error starting service:', error.message);
      process.exit(1);
    }
  }

  async initializeSymbolInfo() {
    try {
      console.log(`[Service] Initializing symbol info for ${this.symbol}`);
      const info = await this.restClient.getSymbolInfo(this.symbol);
      if (info) {
        this.cacheSymbolInfo(this.symbol, info);
        console.log(`[Service] Symbol info cached for ${this.symbol}`);
      }
    } catch (error) {
      console.error(`[Service] Failed to initialize symbol info for ${this.symbol}:`, error.message);
    }
  }

  cacheSymbolInfo(symbol, info) {
    this.symbolInfoCache.set(symbol, {
      data: info,
      timestamp: Date.now()
    });
  }

  getSymbolInfoFromCache(symbol) {
    const cached = this.symbolInfoCache.get(symbol);
    if (!cached) return null;

    const isExpired = Date.now() - cached.timestamp > this.cacheExpiry;
    if (isExpired) {
      this.symbolInfoCache.delete(symbol);
      return null;
    }

    return cached.data;
  }

  async stop() {
    console.log('[Service] Stopping OrderBook service...');

    // Close Binance WebSocket
    this.wsClient.close();

    // Stop WebSocket server
    this.wsServer.stop();

    console.log('[Service] OrderBook service stopped');
  }
}

// Handle graceful shutdown
const service = new OrderBookService();

process.on('SIGINT', async () => {
  console.log('\n[Service] Received SIGINT, shutting down gracefully...');
  await service.stop();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('\n[Service] Received SIGTERM, shutting down gracefully...');
  await service.stop();
  process.exit(0);
});

process.on('uncaughtException', (error) => {
  console.error('[Service] Uncaught exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('[Service] Unhandled rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Start the service
service.start().catch((error) => {
  console.error('[Service] Failed to start:', error.message);
  process.exit(1);
});
