const BaseOrderBook = require('./base-orderbook');

const EventEmitter = require('events');

class LocalOrderBook extends EventEmitter {
  constructor(symbol, options = {}) {
    super();
    this.symbol = symbol;
    this.lastUpdateId = 0;
    this.bids = new Map(); // price -> quantity
    this.asks = new Map(); // price -> quantity
    this.isInitialized = false;
    this.updateBuffer = []; // Buffer for updates received before snapshot
    this.maxLevels = 5000; // Maximum number of price levels to maintain

    // Exchange-specific options
    this.skipSequenceValidation = options.skipSequenceValidation || false;
    this.disableSequenceValidation = options.disableSequenceValidation || false;
  }

  /**
   * Initialize orderbook with snapshot data
   * @param {Object} snapshot - Snapshot from REST API
   */
  initializeFromSnapshot(snapshot) {
    console.log(`[OrderBook] Initializing ${this.symbol} with snapshot, lastUpdateId: ${snapshot.lastUpdateId}`);
    
    this.lastUpdateId = snapshot.lastUpdateId;
    this.bids.clear();
    this.asks.clear();

    // Process bids (sorted by price descending)
    snapshot.bids.forEach(({ price, quantity }) => {
      if (parseFloat(quantity) > 0) {
        this.bids.set(price, quantity);
      }
    });

    // Process asks (sorted by price ascending)
    snapshot.asks.forEach(({ price, quantity }) => {
      if (parseFloat(quantity) > 0) {
        this.asks.set(price, quantity);
      }
    });

    this.isInitialized = true;
    
    // Process any buffered updates
    this.processBufferedUpdates();
    
    this.emit('initialized', this.getSnapshot());
    console.log(`[OrderBook] ${this.symbol} initialized with ${this.bids.size} bids, ${this.asks.size} asks`);
  }

  /**
   * Apply depth update from WebSocket
   * @param {Object} update - Depth update from WebSocket
   * @returns {boolean} True if update was applied successfully
   */
  applyUpdate(update) {
    if (!this.isInitialized) {
      // Buffer updates until we have a snapshot
      this.updateBuffer.push(update);
      console.log(`[OrderBook] Buffering update for ${this.symbol}, buffer size: ${this.updateBuffer.length}`);
      return false;
    }

    // Validate sequence
    if (update.finalUpdateId <= this.lastUpdateId) {
      console.log(`[OrderBook] Ignoring old update for ${this.symbol}: ${update.finalUpdateId} <= ${this.lastUpdateId}`);
      return false;
    }

    // Validate sequence (skip validation for exchanges that don't support it)
    if (!this.skipSequenceValidation && !this.disableSequenceValidation &&
        update.firstUpdateId > this.lastUpdateId + 1) {
      const gap = update.firstUpdateId - (this.lastUpdateId + 1);
      console.warn(`[OrderBook] Sequence gap detected for ${this.symbol}: expected ${this.lastUpdateId + 1}, got ${update.firstUpdateId}, gap: ${gap}`);

      // For small gaps, emit warning but continue processing
      if (gap <= 10) {
        console.warn(`[OrderBook] Small gap (${gap}) detected, continuing with data integrity warning`);
        this.emit('sequenceWarning', {
          expected: this.lastUpdateId + 1,
          received: update.firstUpdateId,
          gap: gap
        });
        // Continue processing despite small gap
      } else {
        console.error(`[OrderBook] Large gap (${gap}) detected, requesting fresh snapshot`);
        this.emit('sequenceGap', {
          expected: this.lastUpdateId + 1,
          received: update.firstUpdateId,
          gap: gap
        });
        return false;
      }
    }

    // Apply bid updates
    const bidChanges = [];
    update.bids.forEach(({ price, quantity }) => {
      const oldQuantity = this.bids.get(price) || '0';
      
      if (parseFloat(quantity) === 0) {
        // Remove price level
        if (this.bids.has(price)) {
          this.bids.delete(price);
          bidChanges.push({ price, quantity: '0', oldQuantity });
        }
      } else {
        // Update price level
        this.bids.set(price, quantity);
        bidChanges.push({ price, quantity, oldQuantity });
      }
    });

    // Apply ask updates
    const askChanges = [];
    update.asks.forEach(({ price, quantity }) => {
      const oldQuantity = this.asks.get(price) || '0';
      
      if (parseFloat(quantity) === 0) {
        // Remove price level
        if (this.asks.has(price)) {
          this.asks.delete(price);
          askChanges.push({ price, quantity: '0', oldQuantity });
        }
      } else {
        // Update price level
        this.asks.set(price, quantity);
        askChanges.push({ price, quantity, oldQuantity });
      }
    });

    this.lastUpdateId = update.finalUpdateId;

    // Trim orderbook if it gets too large
    this.trimOrderBook();

    // Emit update event with changes
    if (bidChanges.length > 0 || askChanges.length > 0) {
      this.emit('update', {
        symbol: this.symbol,
        timestamp: Date.now(),
        lastUpdateId: this.lastUpdateId,
        bidChanges,
        askChanges
      });
    }

    return true;
  }

  /**
   * Process buffered updates after initialization
   */
  processBufferedUpdates() {
    console.log(`[OrderBook] Processing ${this.updateBuffer.length} buffered updates for ${this.symbol}`);
    
    // Sort updates by finalUpdateId
    this.updateBuffer.sort((a, b) => a.finalUpdateId - b.finalUpdateId);
    
    let processedCount = 0;
    for (const update of this.updateBuffer) {
      if (this.applyUpdate(update)) {
        processedCount++;
      }
    }
    
    this.updateBuffer = [];
    console.log(`[OrderBook] Processed ${processedCount} buffered updates for ${this.symbol}`);
  }

  /**
   * Trim orderbook to maintain reasonable size
   */
  trimOrderBook() {
    if (this.bids.size > this.maxLevels) {
      const sortedBids = Array.from(this.bids.entries())
        .sort(([a], [b]) => parseFloat(b) - parseFloat(a)) // Sort by price descending
        .slice(0, this.maxLevels);
      
      this.bids.clear();
      sortedBids.forEach(([price, quantity]) => {
        this.bids.set(price, quantity);
      });
    }

    if (this.asks.size > this.maxLevels) {
      const sortedAsks = Array.from(this.asks.entries())
        .sort(([a], [b]) => parseFloat(a) - parseFloat(b)) // Sort by price ascending (keep best asks)
        .slice(0, this.maxLevels);
      
      this.asks.clear();
      sortedAsks.forEach(([price, quantity]) => {
        this.asks.set(price, quantity);
      });
    }
  }

  /**
   * Get current orderbook snapshot
   * @param {number} limit - Number of levels to return (default: all)
   * @returns {Object} Current orderbook state
   */
  
  getSnapshot(limit = null) {
    // Sort bids by price descending (highest first) - стандарт Binance
    const sortedBids = Array.from(this.bids.entries())
      .sort(([a], [b]) => parseFloat(b) - parseFloat(a))
      .map(([price, quantity]) => ({ price, quantity }));

    // Sort asks by price ascending - cheapest ask first (Binance standard)
    const sortedAsks = Array.from(this.asks.entries())
      .sort(([a], [b]) => parseFloat(a) - parseFloat(b))
      .map(([price, quantity]) => ({ price, quantity }));

    const bids = limit ? sortedBids.slice(0, limit) : sortedBids;
    const asks = limit ? sortedAsks.slice(0, limit) : sortedAsks;

    // Calculate spread (bestBid = highest bid, bestAsk = lowest ask which is now first)
    const bestBid = bids.length > 0 ? parseFloat(bids[0].price) : 0;
    const bestAsk = asks.length > 0 ? parseFloat(asks[0].price) : 0;
    const spread = bestAsk > 0 && bestBid > 0 ? bestAsk - bestBid : 0;
    const spreadPercent = bestBid > 0 ? (spread / bestBid) * 100 : 0;

    return {
      symbol: this.symbol,
      lastUpdateId: this.lastUpdateId,
      timestamp: Date.now(),
      bids,
      asks,
      spread,
      spreadPercent,
      isInitialized: this.isInitialized
    };
  }

  /**
   * Get best bid and ask prices
   * @returns {Object} Best bid and ask
   */
  getBestPrices() {
    const bestBid = this.getBestBid();
    const bestAsk = this.getBestAsk();
    
    return {
      bestBid: bestBid ? parseFloat(bestBid.price) : null,
      bestAsk: bestAsk ? parseFloat(bestAsk.price) : null,
      spread: bestBid && bestAsk ? parseFloat(bestAsk.price) - parseFloat(bestBid.price) : null
    };
  }

  /**
   * Get best bid
   * @returns {Object|null} Best bid or null if no bids
   */
  getBestBid() {
    if (this.bids.size === 0) return null;
    
    const sortedBids = Array.from(this.bids.entries())
      .sort(([a], [b]) => parseFloat(b) - parseFloat(a));
    
    const [price, quantity] = sortedBids[0];
    return { price, quantity };
  }

  /**
   * Get best ask
   * @returns {Object|null} Best ask or null if no asks
   */
  getBestAsk() {
    if (this.asks.size === 0) return null;
    
    const sortedAsks = Array.from(this.asks.entries())
      .sort(([a], [b]) => parseFloat(a) - parseFloat(b));
    
    const [price, quantity] = sortedAsks[0];
    return { price, quantity };
  }

  /**
   * Reset orderbook
   */
  reset() {
    console.log(`[OrderBook] Resetting ${this.symbol}`);
    this.lastUpdateId = 0;
    this.bids.clear();
    this.asks.clear();
    this.isInitialized = false;
    this.updateBuffer = [];
    this.emit('reset');
  }

  /**
   * Get orderbook statistics
   * @returns {Object} Statistics
   */
  getStats() {
    return {
      symbol: this.symbol,
      isInitialized: this.isInitialized,
      lastUpdateId: this.lastUpdateId,
      bidLevels: this.bids.size,
      askLevels: this.asks.size,
      bufferedUpdates: this.updateBuffer.length,
      ...this.getBestPrices()
    };
  }
}

module.exports = LocalOrderBook;
