// Unified Binance OrderBook Server
// Uses the new unified architecture with HTTP/WebSocket on same port

const { UnifiedServer } = require('../../dist/shared/unified-server.js');
const { createLogger } = require('../../dist/shared/utils.js');

async function startBinanceOrderBookService() {
  const logger = createLogger('BINANCE', 'BTCUSDT');
  
  try {
    logger.info('Starting Binance OrderBook service with unified architecture...');
    
    // Create unified server with Binance configuration
    const server = new UnifiedServer({
      port: 3000,
      exchange: 'binance',
      symbol: 'BTCUSDT',
      depthLimit: 1000,
      broadcastHz: 20
    });
    
    // Handle server events
    server.on('started', () => {
      logger.info('Binance OrderBook service started successfully');
      logger.info('Available endpoints:');
      logger.info('  - HTTP: http://localhost:3000');
      logger.info('  - WebSocket: ws://localhost:3000/ws');
      logger.info('  - Health: http://localhost:3000/health');
      logger.info('  - Config: http://localhost:3000/config');
      logger.info('  - Status: http://localhost:3000/status');
    });
    
    server.on('error', (error) => {
      logger.error('Server error:', error);
      process.exit(1);
    });
    
    server.on('upstreamError', (error) => {
      logger.error('Upstream error:', error);
      // Don't exit on upstream errors, let the system recover
    });
    
    // Start the server
    await server.start();
    
    // Handle graceful shutdown
    process.on('SIGINT', async () => {
      logger.info('Received SIGINT, shutting down gracefully...');
      await server.stop();
      process.exit(0);
    });
    
    process.on('SIGTERM', async () => {
      logger.info('Received SIGTERM, shutting down gracefully...');
      await server.stop();
      process.exit(0);
    });
    
  } catch (error) {
    logger.error('Failed to start Binance OrderBook service:', error);
    process.exit(1);
  }
}

// Start the service
startBinanceOrderBookService();
