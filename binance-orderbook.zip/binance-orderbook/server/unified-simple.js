// Simple Unified Binance OrderBook Server
// Self-contained implementation for testing

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fetch = require('node-fetch');

class BinanceUnifiedServer {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.wss = new WebSocket.Server({ noServer: true });
    this.clients = new Set();
    this.orderbook = { bids: [], asks: [] };
    this.isConnected = false;
    this.lastUpdate = 0;
    
    this.setupExpress();
    this.setupWebSocket();
  }
  
  setupExpress() {
    this.app.use(express.json());
    this.app.use(express.static('dist'));
    
    // Health endpoint
    this.app.get('/health', (req, res) => {
      res.json({
        exchange: 'binance',
        symbol: 'BTCUSDT',
        websocket: {
          isRunning: this.isConnected,
          lastBeat: this.lastUpdate
        }
      });
    });
    
    // Config endpoint
    this.app.get('/config', (req, res) => {
      res.json({
        exchange: 'binance',
        symbol: 'BTCUSDT',
        wsPath: '/ws'
      });
    });
    
    // Status endpoint
    this.app.get('/status', (req, res) => {
      res.json({
        exchange: 'binance',
        symbol: 'BTCUSDT',
        upstreamAlive: this.isConnected,
        lastUpstreamBeat: this.lastUpdate,
        connectedClients: this.clients.size,
        orderbook: {
          bidLevels: this.orderbook.bids.length,
          askLevels: this.orderbook.asks.length
        }
      });
    });
  }
  
  setupWebSocket() {
    // Handle HTTP upgrade to WebSocket
    this.server.on('upgrade', (request, socket, head) => {
      if (request.url !== '/ws') {
        socket.destroy();
        return;
      }
      
      this.wss.handleUpgrade(request, socket, head, (ws) => {
        this.wss.emit('connection', ws, request);
      });
    });
    
    // Handle new WebSocket connections
    this.wss.on('connection', (ws) => {
      console.log('[BINANCE] New client connected');
      this.clients.add(ws);
      
      // Send current orderbook if available
      if (this.orderbook.bids.length > 0 || this.orderbook.asks.length > 0) {
        const message = {
          type: 'orderbook',
          exchange: 'binance',
          symbol: 'BTCUSDT',
          ts: Date.now(),
          bids: this.orderbook.bids.slice(0, 20),
          asks: this.orderbook.asks.slice(0, 20)
        };
        ws.send(JSON.stringify(message));
      }
      
      ws.on('close', () => {
        console.log('[BINANCE] Client disconnected');
        this.clients.delete(ws);
      });
      
      ws.on('error', (error) => {
        console.error('[BINANCE] Client error:', error);
        this.clients.delete(ws);
      });
    });
  }
  
  async getSnapshot() {
    try {
      const response = await fetch('https://api.binance.com/api/v3/depth?symbol=BTCUSDT&limit=1000');
      const data = await response.json();
      
      const bids = data.bids.map(([p, q]) => [parseFloat(p), parseFloat(q)]).sort((a, b) => b[0] - a[0]);
      const asks = data.asks.map(([p, q]) => [parseFloat(p), parseFloat(q)]).sort((a, b) => a[0] - b[0]);
      
      this.orderbook = { bids, asks };
      this.lastUpdate = Date.now();
      
      console.log(`[BINANCE] Snapshot loaded: ${bids.length} bids, ${asks.length} asks`);
      this.broadcastOrderbook();
      
    } catch (error) {
      console.error('[BINANCE] Failed to get snapshot:', error);
    }
  }
  
  connectWebSocket() {
    const ws = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@depth@100ms');
    
    ws.on('open', () => {
      console.log('[BINANCE] WebSocket connected');
      this.isConnected = true;
    });
    
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data);
        if (message.e === 'depthUpdate') {
          this.processDepthUpdate(message);
        }
      } catch (error) {
        console.error('[BINANCE] Failed to process message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('[BINANCE] WebSocket disconnected, reconnecting...');
      this.isConnected = false;
      setTimeout(() => this.connectWebSocket(), 5000);
    });
    
    ws.on('error', (error) => {
      console.error('[BINANCE] WebSocket error:', error);
      this.isConnected = false;
    });
  }
  
  processDepthUpdate(update) {
    // Apply bid updates
    if (update.b && update.b.length > 0) {
      for (const [price, qty] of update.b) {
        const p = parseFloat(price);
        const q = parseFloat(qty);
        
        if (q === 0) {
          this.orderbook.bids = this.orderbook.bids.filter(([bidPrice]) => bidPrice !== p);
        } else {
          const index = this.orderbook.bids.findIndex(([bidPrice]) => bidPrice === p);
          if (index >= 0) {
            this.orderbook.bids[index] = [p, q];
          } else {
            this.orderbook.bids.push([p, q]);
          }
        }
      }
      this.orderbook.bids.sort((a, b) => b[0] - a[0]);
    }
    
    // Apply ask updates
    if (update.a && update.a.length > 0) {
      for (const [price, qty] of update.a) {
        const p = parseFloat(price);
        const q = parseFloat(qty);
        
        if (q === 0) {
          this.orderbook.asks = this.orderbook.asks.filter(([askPrice]) => askPrice !== p);
        } else {
          const index = this.orderbook.asks.findIndex(([askPrice]) => askPrice === p);
          if (index >= 0) {
            this.orderbook.asks[index] = [p, q];
          } else {
            this.orderbook.asks.push([p, q]);
          }
        }
      }
      this.orderbook.asks.sort((a, b) => a[0] - b[0]);
    }
    
    this.lastUpdate = Date.now();
    this.broadcastOrderbook();
  }
  
  broadcastOrderbook() {
    if (this.clients.size === 0) return;
    
    const message = {
      type: 'orderbook',
      exchange: 'binance',
      symbol: 'BTCUSDT',
      ts: Date.now(),
      bids: this.orderbook.bids.slice(0, 20),
      asks: this.orderbook.asks.slice(0, 20)
    };
    
    const data = JSON.stringify(message);
    this.clients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  }
  
  async start() {
    return new Promise((resolve) => {
      this.server.listen(3000, async () => {
        console.log('[BINANCE] Server started on port 3000');
        console.log('[BINANCE] HTTP: http://localhost:3000');
        console.log('[BINANCE] WebSocket: ws://localhost:3000/ws');
        console.log('[BINANCE] Health: http://localhost:3000/health');
        console.log('[BINANCE] Config: http://localhost:3000/config');
        
        // Get initial snapshot and start WebSocket
        await this.getSnapshot();
        this.connectWebSocket();
        
        resolve();
      });
    });
  }
  
  async stop() {
    return new Promise((resolve) => {
      this.server.close(() => {
        console.log('[BINANCE] Server stopped');
        resolve();
      });
    });
  }
}

// Start the server
async function main() {
  const server = new BinanceUnifiedServer();
  
  try {
    await server.start();
    
    // Handle graceful shutdown
    process.on('SIGINT', async () => {
      console.log('[BINANCE] Shutting down...');
      await server.stop();
      process.exit(0);
    });
    
  } catch (error) {
    console.error('[BINANCE] Failed to start server:', error);
    process.exit(1);
  }
}

main();
