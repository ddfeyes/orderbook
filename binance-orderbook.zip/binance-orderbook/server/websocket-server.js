const WebSocket = require('ws');
const EventEmitter = require('events');

class WebSocketServer extends EventEmitter {
  constructor(port = 8080) {
    super();
    this.port = port;
    this.wss = null;
    this.clients = new Set();
    this.updateBuffer = [];
    this.batchInterval = null;
    this.batchSize = 1; // Single update per batch for minimum latency
    this.batchTimeout = 16; // 60fps target (16.67ms per frame)
  }

  /**
   * Start the WebSocket server
   */
  start() {
    this.wss = new WebSocket.Server({ 
      port: this.port,
      perMessageDeflate: {
        zlibDeflateOptions: {
          level: 1, // Fastest compression
          chunkSize: 512, // Smaller chunks for lower latency
        },
        threshold: 512, // Lower threshold for compression
        concurrencyLimit: 20, // Higher concurrency
        clientMaxWindowBits: 13, // Smaller window for faster processing
        serverMaxWindowBits: 13, // Smaller window for faster processing
        serverMaxNoContextTakeover: false,
        clientMaxNoContextTakeover: false,
      }
    });

    this.wss.on('connection', (ws, req) => {
      console.log(`[WS Server] New client connected from ${req.socket.remoteAddress}`);
      this.handleNewClient(ws);
    });

    this.wss.on('error', (error) => {
      console.error('[WS Server] Server error:', error);
      this.emit('error', error);
    });

    // Start batching updates
    this.startBatching();

    // Start keepalive mechanism
    this.startKeepalive();

    console.log(`[WS Server] Started on port ${this.port}`);
    this.emit('started');
  }

  /**
   * Handle new client connection
   * @param {WebSocket} ws - WebSocket connection
   */
  handleNewClient(ws) {
    this.clients.add(ws);

    // Send welcome message
    this.sendToClient(ws, {
      type: 'connected',
      data: {
        message: 'Connected to Binance OrderBook WebSocket',
        timestamp: Date.now()
      }
    });

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        this.handleClientMessage(ws, message);
      } catch (error) {
        console.error('[WS Server] Error parsing client message:', error.message);
        this.sendToClient(ws, {
          type: 'error',
          error: 'Invalid JSON message'
        });
      }
    });

    ws.on('close', (code, reason) => {
      console.log(`[WS Server] Client disconnected: ${code} ${reason}`);
      this.clients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('[WS Server] Client error:', error.message);
      this.clients.delete(ws);
    });

    // Setup ping-pong
    ws.isAlive = true;
    ws.on('pong', () => {
      ws.isAlive = true;
    });
  }

  /**
   * Handle messages from clients
   * @param {WebSocket} ws - WebSocket connection
   * @param {Object} message - Parsed message
   */
  handleClientMessage(ws, message) {
    switch (message.type) {
      case 'ping':
        // Echo back the timestamp for accurate ping measurement - immediate response
        const pongMessage = {
          type: 'pong',
          timestamp: message.timestamp || Date.now()
        };
        this.sendToClient(ws, pongMessage);
        break;

      case 'subscribe':
        // Handle subscription requests
        this.handleSubscription(ws, message.data);
        break;

      case 'unsubscribe':
        // Handle unsubscription requests
        this.handleUnsubscription(ws, message.data);
        break;

      default:
        console.log('[WS Server] Unknown message type:', message.type);
    }
  }

  /**
   * Handle subscription requests
   * @param {WebSocket} ws - WebSocket connection
   * @param {Object} data - Subscription data
   */
  handleSubscription(ws, data) {
    // Store subscription info on the WebSocket
    if (!ws.subscriptions) {
      ws.subscriptions = new Set();
    }
    
    const subscription = `${data.symbol}@${data.stream || 'depth'}`;
    ws.subscriptions.add(subscription);
    
    console.log(`[WS Server] Client subscribed to ${subscription}`);
    
    this.sendToClient(ws, {
      type: 'subscribed',
      data: { subscription }
    });

    this.emit('clientSubscribed', { ws, subscription });
  }

  /**
   * Handle unsubscription requests
   * @param {WebSocket} ws - WebSocket connection
   * @param {Object} data - Unsubscription data
   */
  handleUnsubscription(ws, data) {
    if (!ws.subscriptions) return;
    
    const subscription = `${data.symbol}@${data.stream || 'depth'}`;
    ws.subscriptions.delete(subscription);
    
    console.log(`[WS Server] Client unsubscribed from ${subscription}`);
    
    this.sendToClient(ws, {
      type: 'unsubscribed',
      data: { subscription }
    });
  }

  /**
   * Broadcast orderbook update to all subscribed clients
   * @param {Object} update - Orderbook update
   * @param {Object} symbolInfo - Symbol information (optional)
   */
  broadcastOrderBookUpdate(update, symbolInfo = null) {
    const enhancedUpdate = {
      ...update,
      symbolInfo: symbolInfo
    };

    this.updateBuffer.push({
      type: 'orderbook_delta',
      data: enhancedUpdate,
      timestamp: Date.now()
    });
  }

  /**
   * Start batching updates for better performance
   */
  startBatching() {
    this.batchInterval = setInterval(() => {
      if (this.updateBuffer.length > 0) {
        this.flushUpdates();
      }
    }, this.batchTimeout);
  }

  /**
   * Flush buffered updates to clients
   */
  flushUpdates() {
    if (this.updateBuffer.length === 0) return;

    const updates = this.updateBuffer.splice(0, this.batchSize);
    const batchMessage = {
      type: 'batch_update',
      data: updates,
      timestamp: Date.now()
    };

    this.broadcastToSubscribedClients(batchMessage, updates[0]?.data?.symbol);
  }

  /**
   * Broadcast message to clients subscribed to a specific symbol
   * @param {Object} message - Message to broadcast
   * @param {string} symbol - Symbol to filter clients
   */
  broadcastToSubscribedClients(message, symbol) {
    const subscription = `${symbol}@depth`;
    let sentCount = 0;

    this.clients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN && 
          ws.subscriptions && 
          ws.subscriptions.has(subscription)) {
        this.sendToClient(ws, message);
        sentCount++;
      }
    });

    if (sentCount > 0) {
      console.log(`[WS Server] Broadcasted update to ${sentCount} clients for ${symbol}`);
    }
  }

  /**
   * Send message to a specific client
   * @param {WebSocket} ws - WebSocket connection
   * @param {Object} message - Message to send
   */
  sendToClient(ws, message) {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify(message));
      } catch (error) {
        console.error('[WS Server] Error sending message to client:', error.message);
        this.clients.delete(ws);
      }
    }
  }

  /**
   * Broadcast message to all connected clients
   * @param {Object} message - Message to broadcast
   */
  broadcast(message) {
    let sentCount = 0;
    
    this.clients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        this.sendToClient(ws, message);
        sentCount++;
      }
    });

    console.log(`[WS Server] Broadcasted message to ${sentCount} clients`);
  }

  /**
   * Start heartbeat to detect dead connections
   */
  startHeartbeat() {
    setInterval(() => {
      this.clients.forEach(ws => {
        if (!ws.isAlive) {
          console.log('[WS Server] Terminating dead connection');
          ws.terminate();
          this.clients.delete(ws);
          return;
        }
        
        ws.isAlive = false;
        ws.ping();
      });
    }, 30000); // Check every 30 seconds
  }

  /**
   * Get server statistics
   * @returns {Object} Server stats
   */
  getStats() {
    return {
      port: this.port,
      connectedClients: this.clients.size,
      bufferedUpdates: this.updateBuffer.length,
      isRunning: this.wss !== null
    };
  }

  /**
   * Start keepalive mechanism
   */
  startKeepalive() {
    this.keepaliveInterval = setInterval(() => {
      this.clients.forEach(ws => {
        if (ws.isAlive === false) {
          console.log('[WS Server] Terminating dead connection');
          return ws.terminate();
        }

        ws.isAlive = false;
        ws.ping();
      });
    }, 30000); // Check every 30 seconds
  }

  /**
   * Stop the WebSocket server
   */
  stop() {
    console.log('[WS Server] Stopping server...');

    if (this.batchInterval) {
      clearInterval(this.batchInterval);
      this.batchInterval = null;
    }

    // Stop keepalive
    if (this.keepaliveInterval) {
      clearInterval(this.keepaliveInterval);
      this.keepaliveInterval = null;
    }

    // Close all client connections
    this.clients.forEach(ws => {
      ws.close(1000, 'Server shutting down');
    });
    this.clients.clear();

    // Close server
    if (this.wss) {
      this.wss.close(() => {
        console.log('[WS Server] Server stopped');
        this.emit('stopped');
      });
      this.wss = null;
    }
  }
}

module.exports = WebSocketServer;
