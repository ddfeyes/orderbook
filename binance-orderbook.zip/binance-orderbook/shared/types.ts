// Shared types for Binance orderbook implementation

export interface OrderBookLevel {
  price: string;
  quantity: string;
}

export interface OrderBookSnapshot {
  lastUpdateId: number;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
}

export interface OrderBookUpdate {
  e: string; // Event type
  E: number; // Event time
  s: string; // Symbol
  U: number; // First update ID in event
  u: number; // Final update ID in event
  b: OrderBookLevel[]; // Bids to be updated
  a: OrderBookLevel[]; // Asks to be updated
}

export interface LocalOrderBook {
  symbol: string;
  lastUpdateId: number;
  bids: Map<string, string>; // price -> quantity
  asks: Map<string, string>; // price -> quantity
}

export interface OrderBookDelta {
  type: 'snapshot' | 'update';
  symbol: string;
  timestamp: number;
  bids?: OrderBookLevel[];
  asks?: OrderBookLevel[];
  lastUpdateId?: number;
}

export interface WebSocketMessage {
  type: 'orderbook_delta' | 'error' | 'connected' | 'disconnected';
  data?: any;
  error?: string;
}

export interface SymbolInfo {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  tickSize: string;
  stepSize: string;
  minNotional: string;
}

export interface GroupingLevel {
  value: number;
  label: string;
}

export interface OrderBookMetrics {
  totalBidsVolume: number;
  totalAsksVolume: number;
  totalBidsValue: number; // in USDT
  totalAsksValue: number; // in USDT
  averageExecutionPrice: number; // weighted average price up to cursor
  volumeAtPlusPercent: number; // USDT volume within +X% from current price
  volumeAtMinusPercent: number; // USDT volume within -X% from current price
  currentPrice: number;
  liquidityPercent: number; // Current liquidity percentage (0.1% to 20%)
}

export interface PriceImpactData {
  priceImpact: number; // percentage
  averagePrice: number;
  totalCost: number; // in USDT
  totalVolume: number; // in BTC
  side: 'bid' | 'ask';
}

export interface RendererConfig {
  width: number;
  height: number;
  maxLevels: number;
  priceDecimals: number;
  quantityDecimals: number;
  animationDuration: number;
  groupingLevel: GroupingLevel;
  showMetrics: boolean;
  colors: {
    background: string;
    bid: string;
    ask: string;
    text: string;
    border: string;
    highlight: string;
    cursor: string;
    metrics: string;
  };
}

export interface OrderBookState {
  connected: boolean;
  symbol: string;
  symbolInfo?: SymbolInfo;
  lastUpdate: number;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  spreadPercent: number;
  metrics: OrderBookMetrics;
  cursorPosition?: number; // index of the level where cursor is positioned
  groupingLevel: GroupingLevel;
}
