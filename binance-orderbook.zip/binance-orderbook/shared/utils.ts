// Utility functions for orderbook processing

import { OrderBookLevel, GroupingLevel, OrderBookMetrics, SymbolInfo } from './types';

/**
 * Format number by removing trailing zeros and unnecessary decimals
 */
export function formatNumber(value: number | string, maxDecimals: number = 8): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  
  // Format with max decimals and remove trailing zeros
  const formatted = num.toFixed(maxDecimals);
  return formatted.replace(/\.?0+$/, '');
}

/**
 * Format large numbers with K, M, B suffixes
 */
export function formatLargeNumber(value: number): string {
  if (value >= 1e9) {
    return formatNumber(value / 1e9, 2) + 'B';
  } else if (value >= 1e6) {
    return formatNumber(value / 1e6, 2) + 'M';
  } else if (value >= 1e3) {
    return formatNumber(value / 1e3, 2) + 'K';
  }
  return formatNumber(value, 2);
}

/**
 * Generate grouping levels based on tick size
 */
export function generateGroupingLevels(tickSize: string): GroupingLevel[] {
  const tick = parseFloat(tickSize);

  return [
    { value: tick, label: formatNumber(tick) },
    { value: tick * 10, label: formatNumber(tick * 10) },
    { value: tick * 100, label: formatNumber(tick * 100) },
    { value: tick * 1000, label: formatNumber(tick * 1000) }
  ];
}

/**
 * Group orderbook levels by specified grouping level
 */
export function groupOrderBookLevels(
  levels: OrderBookLevel[], 
  groupingLevel: GroupingLevel,
  isBids: boolean = true
): OrderBookLevel[] {
  if (groupingLevel.value <= 0) return levels;
  
  const grouped = new Map<string, number>();
  
  for (const level of levels) {
    const price = parseFloat(level.price);
    const quantity = parseFloat(level.quantity);
    
    // Group price to nearest grouping level
    let groupedPrice: number;
    if (isBids) {
      // For bids, round down to group level
      groupedPrice = Math.floor(price / groupingLevel.value) * groupingLevel.value;
    } else {
      // For asks, round up to group level
      groupedPrice = Math.ceil(price / groupingLevel.value) * groupingLevel.value;
    }
    
    const priceKey = groupedPrice.toFixed(8);
    const existingQuantity = grouped.get(priceKey) || 0;
    grouped.set(priceKey, existingQuantity + quantity);
  }
  
  // Convert back to OrderBookLevel array and sort
  const result = Array.from(grouped.entries()).map(([price, quantity]) => ({
    price: formatNumber(parseFloat(price)),
    quantity: formatNumber(quantity)
  }));
  
  // Sort: bids descending, asks ascending
  result.sort((a, b) => {
    const priceA = parseFloat(a.price);
    const priceB = parseFloat(b.price);
    return isBids ? priceB - priceA : priceA - priceB;
  });
  
  return result;
}

/**
 * Calculate orderbook metrics
 */
export function calculateOrderBookMetrics(
  bids: OrderBookLevel[],
  asks: OrderBookLevel[],
  cursorPosition?: number,
  currentPrice?: number,
  liquidityPercent: number = 2
): OrderBookMetrics {
  // Calculate total volumes
  const totalBidsVolume = bids.reduce((sum, level) => sum + parseFloat(level.quantity), 0);
  const totalAsksVolume = asks.reduce((sum, level) => sum + parseFloat(level.quantity), 0);
  
  // Calculate total values in USDT
  const totalBidsValue = bids.reduce((sum, level) => {
    return sum + (parseFloat(level.price) * parseFloat(level.quantity));
  }, 0);
  
  const totalAsksValue = asks.reduce((sum, level) => {
    return sum + (parseFloat(level.price) * parseFloat(level.quantity));
  }, 0);
  
  // Calculate average execution price up to cursor
  let averageExecutionPrice = 0;
  if (cursorPosition !== undefined && bids.length > 0) {
    const levelsUpToCursor = bids.slice(0, cursorPosition + 1);
    let totalValue = 0;
    let totalVolume = 0;
    
    for (const level of levelsUpToCursor) {
      const price = parseFloat(level.price);
      const quantity = parseFloat(level.quantity);
      totalValue += price * quantity;
      totalVolume += quantity;
    }
    
    averageExecutionPrice = totalVolume > 0 ? totalValue / totalVolume : 0;
  }
  
  // Get current price (best bid or provided price)
  const bestBid = bids.length > 0 ? parseFloat(bids[0].price) : 0;
  const bestAsk = asks.length > 0 ? parseFloat(asks[0].price) : 0;
  const midPrice = (bestBid + bestAsk) / 2;
  const price = currentPrice || midPrice;
  
  // Calculate volume within +X% and -X% from current price
  const multiplier = 1 + (liquidityPercent / 100);
  const upperBound = price * multiplier;
  const lowerBound = price / multiplier;

  let volumeAtPlusPercent = 0;
  let volumeAtMinusPercent = 0;
  
  // Check asks within +X%
  for (const level of asks) {
    const askPrice = parseFloat(level.price);
    if (askPrice <= upperBound) {
      volumeAtPlusPercent += askPrice * parseFloat(level.quantity);
    } else {
      break; // Asks are sorted ascending, so we can break early
    }
  }

  // Check bids within -X%
  for (const level of bids) {
    const bidPrice = parseFloat(level.price);
    if (bidPrice >= lowerBound) {
      volumeAtMinusPercent += bidPrice * parseFloat(level.quantity);
    } else {
      break; // Bids are sorted descending, so we can break early
    }
  }
  
  return {
    totalBidsVolume,
    totalAsksVolume,
    totalBidsValue,
    totalAsksValue,
    averageExecutionPrice,
    volumeAtPlusPercent,
    volumeAtMinusPercent,
    currentPrice: price,
    liquidityPercent
  };
}

/**
 * Calculate price change percentage
 */
export function calculatePriceChangePercent(currentPrice: number, previousPrice: number): number {
  if (previousPrice === 0) return 0;
  return ((currentPrice - previousPrice) / previousPrice) * 100;
}

/**
 * Calculate price impact for a given order level
 */
export function calculatePriceImpact(
  levels: OrderBookLevel[],
  targetIndex: number,
  side: 'bid' | 'ask',
  currentPrice: number
): { priceImpact: number; averagePrice: number; totalCost: number; totalVolume: number } {
  if (targetIndex < 0 || targetIndex >= levels.length) {
    return { priceImpact: 0, averagePrice: 0, totalCost: 0, totalVolume: 0 };
  }

  let totalCost = 0;
  let totalVolume = 0;

  // Calculate cumulative cost and volume up to target level
  for (let i = 0; i <= targetIndex; i++) {
    const level = levels[i];
    const price = parseFloat(level.price);
    const quantity = parseFloat(level.quantity);

    totalCost += price * quantity;
    totalVolume += quantity;
  }

  if (totalVolume === 0) {
    return { priceImpact: 0, averagePrice: 0, totalCost: 0, totalVolume: 0 };
  }

  const averagePrice = totalCost / totalVolume;

  // Правильная формула для Price Impact:
  // Для асков: (targetPrice/currentPrice - 1) * 100
  // Для бидов: (1 - targetPrice/currentPrice) * 100
  let priceImpact: number;
  if (side === 'ask') {
    priceImpact = (averagePrice / currentPrice - 1) * 100;
  } else {
    priceImpact = (1 - averagePrice / currentPrice) * 100;
  }

  return {
    priceImpact,
    averagePrice,
    totalCost,
    totalVolume
  };
}

/**
 * Get liquidity levels for slider
 */
export function getLiquidityLevels(): { value: number; label: string }[] {
  return [
    { value: 0.1, label: '0.1%' },
    { value: 0.2, label: '0.2%' },
    { value: 0.5, label: '0.5%' },
    { value: 1, label: '1%' },
    { value: 2, label: '2%' },
    { value: 5, label: '5%' },
    { value: 10, label: '10%' },
    { value: 20, label: '20%' }
  ];
}

/**
 * Animate value changes with easing
 */
export function easeInOutCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

/**
 * Interpolate between two values
 */
export function lerp(start: number, end: number, t: number): number {
  return start + (end - start) * t;
}

/**
 * Get color based on price change
 */
export function getPriceChangeColor(change: number): string {
  if (change > 0) return '#00d4aa'; // Green for positive
  if (change < 0) return '#f84960'; // Red for negative
  return '#848e9c'; // Gray for no change
}
